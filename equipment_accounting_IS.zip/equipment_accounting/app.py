#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Информационная система «Учёт техники техникума»
ПМ.06 Сопровождение информационных систем
"""

import os
import sqlite3
import shutil
from datetime import datetime
from functools import wraps

from flask import (Flask, render_template, request, redirect, url_for,
                   flash, session, send_file, jsonify)
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = "technikum-equipment-secret-key-2026-pm06"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "database.db")
BACKUP_DIR = os.path.join(BASE_DIR, "backups")

os.makedirs(BACKUP_DIR, exist_ok=True)


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def init_db():
    """Создание таблиц и начальных данных"""
    conn = get_db()
    cur = conn.cursor()

    cur.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            full_name TEXT,
            role TEXT NOT NULL DEFAULT 'operator'  -- admin / operator
        );

        CREATE TABLE IF NOT EXISTS equipment_types (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL
        );

        CREATE TABLE IF NOT EXISTS locations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            building TEXT,
            room TEXT
        );

        CREATE TABLE IF NOT EXISTS employees (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            full_name TEXT NOT NULL,
            position TEXT,
            department TEXT,
            phone TEXT
        );

        CREATE TABLE IF NOT EXISTS equipment (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            inventory_number TEXT UNIQUE NOT NULL,
            name TEXT NOT NULL,
            type_id INTEGER,
            model TEXT,
            serial_number TEXT,
            location_id INTEGER,
            responsible_id INTEGER,
            status TEXT NOT NULL DEFAULT 'в эксплуатации',
            purchase_date TEXT,
            cost REAL,
            notes TEXT,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (type_id) REFERENCES equipment_types(id),
            FOREIGN KEY (location_id) REFERENCES locations(id),
            FOREIGN KEY (responsible_id) REFERENCES employees(id)
        );

        CREATE TABLE IF NOT EXISTS movement_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            equipment_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            old_location_id INTEGER,
            new_location_id INTEGER,
            old_status TEXT,
            new_status TEXT,
            changed_by TEXT,
            changed_at TEXT DEFAULT CURRENT_TIMESTAMP,
            comment TEXT,
            FOREIGN KEY (equipment_id) REFERENCES equipment(id) ON DELETE CASCADE
        );
    """)

    # Начальные пользователи
    cur.execute("SELECT COUNT(*) FROM users")
    if cur.fetchone()[0] == 0:
        cur.execute(
            "INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)",
            ("admin", generate_password_hash("admin"), "Администратор системы", "admin")
        )
        cur.execute(
            "INSERT INTO users (username, password_hash, full_name, role) VALUES (?, ?, ?, ?)",
            ("operator", generate_password_hash("operator"), "Системный администратор", "operator")
        )

    # Типы техники
    types = ["Компьютер", "Ноутбук", "Монитор", "Принтер", "МФУ",
             "Проектор", "Интерактивная доска", "Сервер", "Коммутатор", "Прочее"]
    for t in types:
        cur.execute("INSERT OR IGNORE INTO equipment_types (name) VALUES (?)", (t,))

    # Кабинеты
    locations = [
        ("Кабинет 101", "Главный корпус", "101"),
        ("Кабинет 214", "Главный корпус", "214"),
        ("Кабинет 305", "Главный корпус", "305"),
        ("Кабинет информатики 1", "Главный корпус", "211"),
        ("Кабинет информатики 2", "Главный корпус", "212"),
        ("Серверная", "Главный корпус", "001"),
        ("Склад ИТ", "Хозяйственный корпус", "Склад"),
    ]
    cur.execute("SELECT COUNT(*) FROM locations")
    if cur.fetchone()[0] == 0:
        cur.executemany(
            "INSERT INTO locations (name, building, room) VALUES (?, ?, ?)", locations
        )

    # Сотрудники
    employees = [
        ("Иванов Пётр Сергеевич", "Системный администратор", "ИТ-отдел", "+7-900-111-22-33"),
        ("Петрова Анна Владимировна", "Заведующая кабинетом", "Информатика", "+7-900-222-33-44"),
        ("Сидоров Алексей Николаевич", "Преподаватель", "Информатика", "+7-900-333-44-55"),
        ("Козлова Елена Ивановна", "Заведующая кабинетом", "Математика", "+7-900-444-55-66"),
    ]
    cur.execute("SELECT COUNT(*) FROM employees")
    if cur.fetchone()[0] == 0:
        cur.executemany(
            "INSERT INTO employees (full_name, position, department, phone) VALUES (?, ?, ?, ?)",
            employees
        )

    # Пример техники
    cur.execute("SELECT COUNT(*) FROM equipment")
    if cur.fetchone()[0] == 0:
        sample = [
            ("ИНВ-001", "Системный блок", 1, "Intel Core i5 / 16GB / 512SSD", "SN-PC-001", 4, 1, "в эксплуатации", "2023-09-01", 45000),
            ("ИНВ-002", "Монитор 24\"", 3, "Samsung S24R350", "SN-MON-002", 4, 1, "в эксплуатации", "2023-09-01", 12000),
            ("ИНВ-003", "Ноутбук", 2, "Lenovo IdeaPad 3", "SN-NB-003", 5, 2, "в эксплуатации", "2024-02-15", 38000),
            ("ИНВ-004", "МФУ", 5, "HP LaserJet Pro MFP", "SN-MFP-004", 2, 3, "в эксплуатации", "2022-11-20", 28000),
            ("ИНВ-005", "Проектор", 6, "Epson EB-X51", "SN-PRJ-005", 1, 4, "в ремонте", "2021-05-10", 35000),
            ("ИНВ-006", "Коммутатор 24 порта", 9, "TP-Link TL-SG1024", "SN-SW-006", 6, 1, "в эксплуатации", "2020-03-12", 9000),
            ("ИНВ-007", "Системный блок", 1, "AMD Ryzen 5 / 32GB", "SN-PC-007", 5, 2, "на складе", "2024-08-01", 52000),
        ]
        cur.executemany("""
            INSERT INTO equipment
            (inventory_number, name, type_id, model, serial_number, location_id, responsible_id, status, purchase_date, cost)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, sample)

    conn.commit()
    conn.close()


# ---------- Авторизация ----------

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            flash("Требуется вход в систему", "warning")
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if session.get("role") != "admin":
            flash("Доступ только для администратора", "danger")
            return redirect(url_for("index"))
        return f(*args, **kwargs)
    return decorated


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        conn = get_db()
        user = conn.execute(
            "SELECT * FROM users WHERE username = ?", (username,)
        ).fetchone()
        conn.close()
        if user and check_password_hash(user["password_hash"], password):
            session["user_id"] = user["id"]
            session["username"] = user["username"]
            session["full_name"] = user["full_name"]
            session["role"] = user["role"]
            flash(f"Добро пожаловать, {user['full_name']}!", "success")
            return redirect(url_for("index"))
        flash("Неверный логин или пароль", "danger")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    flash("Вы вышли из системы", "info")
    return redirect(url_for("login"))


# ---------- Главная / список техники ----------

@app.route("/")
@login_required
def index():
    q = request.args.get("q", "").strip()
    status = request.args.get("status", "")
    type_id = request.args.get("type_id", "")
    location_id = request.args.get("location_id", "")

    conn = get_db()
    sql = """
        SELECT e.*, t.name AS type_name, l.name AS location_name,
               emp.full_name AS responsible_name
        FROM equipment e
        LEFT JOIN equipment_types t ON e.type_id = t.id
        LEFT JOIN locations l ON e.location_id = l.id
        LEFT JOIN employees emp ON e.responsible_id = emp.id
        WHERE 1=1
    """
    params = []
    if q:
        sql += " AND (e.inventory_number LIKE ? OR e.name LIKE ? OR e.model LIKE ? OR e.serial_number LIKE ?)"
        params.extend([f"%{q}%"] * 4)
    if status:
        sql += " AND e.status = ?"
        params.append(status)
    if type_id:
        sql += " AND e.type_id = ?"
        params.append(type_id)
    if location_id:
        sql += " AND e.location_id = ?"
        params.append(location_id)
    sql += " ORDER BY e.inventory_number"

    items = conn.execute(sql, params).fetchall()
    types = conn.execute("SELECT * FROM equipment_types ORDER BY name").fetchall()
    locations = conn.execute("SELECT * FROM locations ORDER BY name").fetchall()
    conn.close()

    return render_template("index.html", items=items, types=types, locations=locations,
                           q=q, status=status, type_id=type_id, location_id=location_id)


# ---------- Карточка / добавление / редактирование ----------

@app.route("/equipment/<int:item_id>")
@login_required
def equipment_view(item_id):
    conn = get_db()
    item = conn.execute("""
        SELECT e.*, t.name AS type_name, l.name AS location_name,
               emp.full_name AS responsible_name
        FROM equipment e
        LEFT JOIN equipment_types t ON e.type_id = t.id
        LEFT JOIN locations l ON e.location_id = l.id
        LEFT JOIN employees emp ON e.responsible_id = emp.id
        WHERE e.id = ?
    """, (item_id,)).fetchone()
    if not item:
        flash("Запись не найдена", "warning")
        return redirect(url_for("index"))
    history = conn.execute("""
        SELECT h.*, l1.name AS old_loc, l2.name AS new_loc
        FROM movement_history h
        LEFT JOIN locations l1 ON h.old_location_id = l1.id
        LEFT JOIN locations l2 ON h.new_location_id = l2.id
        WHERE h.equipment_id = ?
        ORDER BY h.changed_at DESC
    """, (item_id,)).fetchall()
    conn.close()
    return render_template("equipment_view.html", item=item, history=history)


@app.route("/equipment/add", methods=["GET", "POST"])
@login_required
def equipment_add():
    conn = get_db()
    if request.method == "POST":
        try:
            cur = conn.cursor()
            cur.execute("""
                INSERT INTO equipment
                (inventory_number, name, type_id, model, serial_number,
                 location_id, responsible_id, status, purchase_date, cost, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                request.form["inventory_number"].strip(),
                request.form["name"].strip(),
                request.form.get("type_id") or None,
                request.form.get("model"),
                request.form.get("serial_number"),
                request.form.get("location_id") or None,
                request.form.get("responsible_id") or None,
                request.form.get("status", "в эксплуатации"),
                request.form.get("purchase_date") or None,
                request.form.get("cost") or None,
                request.form.get("notes"),
            ))
            eid = cur.lastrowid
            cur.execute("""
                INSERT INTO movement_history (equipment_id, action, new_location_id, new_status, changed_by, comment)
                VALUES (?, 'Создание', ?, ?, ?, 'Добавление новой единицы техники')
            """, (eid, request.form.get("location_id") or None,
                  request.form.get("status", "в эксплуатации"),
                  session.get("full_name", "system")))
            conn.commit()
            flash("Техника успешно добавлена", "success")
            return redirect(url_for("equipment_view", item_id=eid))
        except sqlite3.IntegrityError:
            flash("Инвентарный номер уже существует", "danger")
        finally:
            conn.close()
    else:
        types = conn.execute("SELECT * FROM equipment_types ORDER BY name").fetchall()
        locations = conn.execute("SELECT * FROM locations ORDER BY name").fetchall()
        employees = conn.execute("SELECT * FROM employees ORDER BY full_name").fetchall()
        conn.close()
        return render_template("equipment_form.html", item=None, types=types,
                               locations=locations, employees=employees)


@app.route("/equipment/<int:item_id>/edit", methods=["GET", "POST"])
@login_required
def equipment_edit(item_id):
    conn = get_db()
    item = conn.execute("SELECT * FROM equipment WHERE id = ?", (item_id,)).fetchone()
    if not item:
        flash("Запись не найдена", "warning")
        conn.close()
        return redirect(url_for("index"))

    if request.method == "POST":
        old_status = item["status"]
        old_loc = item["location_id"]
        new_status = request.form.get("status", old_status)
        new_loc = request.form.get("location_id") or None
        if new_loc:
            new_loc = int(new_loc)

        cur = conn.cursor()
        cur.execute("""
            UPDATE equipment SET
                inventory_number=?, name=?, type_id=?, model=?, serial_number=?,
                location_id=?, responsible_id=?, status=?, purchase_date=?, cost=?, notes=?
            WHERE id=?
        """, (
            request.form["inventory_number"].strip(),
            request.form["name"].strip(),
            request.form.get("type_id") or None,
            request.form.get("model"),
            request.form.get("serial_number"),
            new_loc,
            request.form.get("responsible_id") or None,
            new_status,
            request.form.get("purchase_date") or None,
            request.form.get("cost") or None,
            request.form.get("notes"),
            item_id,
        ))

        if old_status != new_status or old_loc != new_loc:
            cur.execute("""
                INSERT INTO movement_history
                (equipment_id, action, old_location_id, new_location_id, old_status, new_status, changed_by, comment)
                VALUES (?, 'Изменение', ?, ?, ?, ?, ?, ?)
            """, (item_id, old_loc, new_loc, old_status, new_status,
                  session.get("full_name", "system"),
                  request.form.get("comment", "")))
        conn.commit()
        conn.close()
        flash("Данные обновлены", "success")
        return redirect(url_for("equipment_view", item_id=item_id))

    types = conn.execute("SELECT * FROM equipment_types ORDER BY name").fetchall()
    locations = conn.execute("SELECT * FROM locations ORDER BY name").fetchall()
    employees = conn.execute("SELECT * FROM employees ORDER BY full_name").fetchall()
    conn.close()
    return render_template("equipment_form.html", item=item, types=types,
                           locations=locations, employees=employees)


@app.route("/equipment/<int:item_id>/delete", methods=["POST"])
@login_required
@admin_required
def equipment_delete(item_id):
    conn = get_db()
    conn.execute("DELETE FROM equipment WHERE id = ?", (item_id,))
    conn.commit()
    conn.close()
    flash("Запись удалена", "info")
    return redirect(url_for("index"))


# ---------- Отчёты ----------

@app.route("/reports")
@login_required
def reports():
    conn = get_db()
    by_status = conn.execute("""
        SELECT status, COUNT(*) AS cnt FROM equipment GROUP BY status ORDER BY cnt DESC
    """).fetchall()
    by_type = conn.execute("""
        SELECT t.name, COUNT(*) AS cnt
        FROM equipment e JOIN equipment_types t ON e.type_id = t.id
        GROUP BY t.name ORDER BY cnt DESC
    """).fetchall()
    by_location = conn.execute("""
        SELECT l.name, COUNT(*) AS cnt
        FROM equipment e JOIN locations l ON e.location_id = l.id
        GROUP BY l.name ORDER BY cnt DESC
    """).fetchall()
    total = conn.execute("SELECT COUNT(*) FROM equipment").fetchone()[0]
    total_cost = conn.execute("SELECT COALESCE(SUM(cost),0) FROM equipment WHERE status != 'списано'").fetchone()[0]
    conn.close()
    return render_template("reports.html", by_status=by_status, by_type=by_type,
                           by_location=by_location, total=total, total_cost=total_cost)


# ---------- Резервное копирование ----------

@app.route("/backup", methods=["POST"])
@login_required
def create_backup():
    """Рабочая кнопка создания резервной копии БД"""
    try:
        timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
        backup_name = f"database_backup_{timestamp}.db"
        backup_path = os.path.join(BACKUP_DIR, backup_name)

        # Консистентная копия через SQLite API
        src = sqlite3.connect(DB_PATH)
        dst = sqlite3.connect(backup_path)
        with dst:
            src.backup(dst)
        src.close()
        dst.close()

        size_kb = round(os.path.getsize(backup_path) / 1024, 1)
        flash(f"Резервная копия успешно создана: {backup_name} ({size_kb} КБ)", "success")
    except Exception as e:
        flash(f"Ошибка создания резервной копии: {e}", "danger")
    return redirect(request.referrer or url_for("index"))


@app.route("/backups")
@login_required
def list_backups():
    files = []
    for name in sorted(os.listdir(BACKUP_DIR), reverse=True):
        if name.endswith(".db"):
            path = os.path.join(BACKUP_DIR, name)
            size = round(os.path.getsize(path) / 1024, 1)
            mtime = datetime.fromtimestamp(os.path.getmtime(path)).strftime("%d.%m.%Y %H:%M")
            files.append({"name": name, "size": size, "mtime": mtime})
    return render_template("backups.html", files=files)


@app.route("/backups/download/<path:filename>")
@login_required
def download_backup(filename):
    path = os.path.join(BACKUP_DIR, filename)
    if os.path.isfile(path) and filename.endswith(".db"):
        return send_file(path, as_attachment=True)
    flash("Файл не найден", "warning")
    return redirect(url_for("list_backups"))


# ---------- Справочники (упрощённо) ----------

@app.route("/directories")
@login_required
def directories():
    conn = get_db()
    types = conn.execute("SELECT * FROM equipment_types ORDER BY name").fetchall()
    locations = conn.execute("SELECT * FROM locations ORDER BY name").fetchall()
    employees = conn.execute("SELECT * FROM employees ORDER BY full_name").fetchall()
    conn.close()
    return render_template("directories.html", types=types, locations=locations, employees=employees)


# ---------- Запуск ----------

if __name__ == "__main__":
    init_db()
    print("=" * 50)
    print("ИС «Учёт техники техникума» запущена")
    print("Логин: admin / admin   или   operator / operator")
    print("Откройте: http://127.0.0.1:5000")
    print("=" * 50)
    app.run(host="0.0.0.0", port=5000, debug=True)
