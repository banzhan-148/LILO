"""Тесты внешних модулей (карты)."""
import json
import sqlite3
from datetime import date, timedelta

from config import TestingConfig
from tests.conftest import login


def _db():
    return sqlite3.connect(TestingConfig.DATABASE)


def _make_order(number='T-1', status='в работе', due=None, worker=1):
    db = _db()
    due = due or (date.today() + timedelta(days=2)).isoformat()
    db.execute("INSERT INTO orders (number, client_id, worker_id, status, due_date) "
               "VALUES (?, 1, ?, ?, ?)", (number, worker, status, due))
    db.commit()
    oid = db.execute('SELECT id FROM orders WHERE number=?', (number,)).fetchone()[0]
    db.close()
    return oid


def test_modules_index(auth_client):
    rv = auth_client.get('/modules/')
    assert rv.status_code == 200
    html = rv.get_data(as_text=True)
    for name in ('Карта мерок', 'Карта местонахождения', 'Карта загрузки'):
        assert name in html


def test_measure_card(auth_client):
    db = _db()
    db.execute("INSERT INTO measurements (client_id, taken_at, data_json) VALUES (1,'2026-01-01',?)",
               (json.dumps({'рост': 170, 'обхват_талии': 80, 'носок': 38}, ensure_ascii=False),))
    db.execute("INSERT INTO measurements (client_id, taken_at, data_json) VALUES (1,'2026-02-01',?)",
               (json.dumps({'рост': 170, 'обхват_талии': 78}, ensure_ascii=False),))
    db.commit(); db.close()
    rv = auth_client.get('/modules/measure?client_id=1')
    assert rv.status_code == 200
    html = rv.get_data(as_text=True)
    assert 'Обхват талии' in html and '-2.0' in html


def test_location_move(auth_client):
    oid = _make_order()
    rv = auth_client.post('/modules/location',
                          data={'order_id': oid, 'zone': 'cutting', 'note': 'полка 3'},
                          follow_redirects=True)
    assert rv.status_code == 200
    assert 'Раскрой' in rv.get_data(as_text=True)
    rv = auth_client.post('/modules/location', data={'order_id': oid, 'zone': 'hack'},
                          follow_redirects=True)
    assert 'Неизвестная зона' in rv.get_data(as_text=True)


def test_location_director_readonly(client):
    login(client, 'director', 'director1')
    oid = _make_order('T-2')
    client.post('/modules/location', data={'order_id': oid, 'zone': 'pickup'})
    db = _db()
    assert db.execute('SELECT COUNT(*) FROM order_locations').fetchone()[0] == 0
    db.close()


def test_workload(auth_client):
    _make_order('T-3', due=(date.today() - timedelta(days=1)).isoformat())
    _make_order('T-4')
    rv = auth_client.get('/modules/workload?days=7')
    assert rv.status_code == 200
    assert 'Test Worker' in rv.get_data(as_text=True)


def test_modules_require_auth(client):
    for url in ('/modules/', '/modules/measure', '/modules/location', '/modules/workload'):
        assert client.get(url).status_code in (302, 401, 403)
