"""
Файловая шина Ателье: приём заявок из to_atelier/ и отправка статусов в to_tkan/.
"""
from __future__ import annotations

import logging
import re
from typing import Any

logger = logging.getLogger(__name__)

_BUS_REF_RE = re.compile(r"\[BUS:([^\]]+)\]")


def extract_external_ref(description: str | None) -> str | None:
    if not description:
        return None
    m = _BUS_REF_RE.search(description)
    return m.group(1).strip() if m else None


def process_incoming_requests() -> list[dict[str, Any]]:
    """
    Прочитать JSON из to_atelier/, создать заказы «ремонт», перенести файлы в done/,
    записать начальный статус в to_tkan/.
    """
    import file_bus
    from services.orders import OrderService
    from services.clients import ClientService
    from db import q

    results = []
    for path, data in file_bus.list_repair_requests():
        external_ref = (data.get("external_ref") or "").strip()
        if not external_ref:
            file_bus.mark_done(path)
            continue

        # уже есть такой заказ?
        existing = q(
            "SELECT id, number, status FROM orders "
            "WHERE is_deleted=0 AND description LIKE ?",
            (f"%[BUS:{external_ref}]%",),
            one=True,
        )
        if existing:
            file_bus.write_repair_status(
                external_ref=external_ref,
                status=existing["status"],
                order_number=existing["number"],
                order_id=existing["id"],
            )
            file_bus.mark_done(path)
            results.append({"external_ref": external_ref, "duplicate": True, **existing})
            continue

        customer = data.get("customer") or {}
        item = data.get("item") or {}
        name = (customer.get("name") or "Клиент магазина").strip()
        phone = (customer.get("phone") or "").strip()
        email = (customer.get("email") or "").strip()
        defect = (data.get("defect") or "").strip() or "Брак"
        note = (data.get("note") or "").strip()
        item_name = (item.get("name") or "Изделие").strip()
        size = (item.get("size") or "").strip()
        try:
            qty = max(1, int(item.get("qty") or 1))
        except (TypeError, ValueError):
            qty = 1
        display_item = item_name + (f" ({size})" if size else "")

        client_id = None
        if phone:
            row = q(
                "SELECT id FROM clients WHERE is_deleted=0 AND phone=? LIMIT 1",
                (phone,),
                one=True,
            )
            if row:
                client_id = row["id"]
        if client_id is None:
            try:
                client_id = ClientService.create(full_name=name, phone=phone, email=email)
            except ValueError as e:
                msg = str(e)
                if msg.startswith("duplicate:"):
                    client_id = int(msg.split(":", 1)[1])
                else:
                    logger.warning("bus client create failed: %s", e)
                    results.append({"external_ref": external_ref, "error": msg})
                    continue

        description = "\n".join([
            f"[BUS:{external_ref}]",
            "Источник: tkan (файловая шина)",
            f"Дефект: {defect}",
            *([f"Примечание: {note}"] if note else []),
        ])

        try:
            oid = OrderService.create(
                client_id=client_id,
                worker_id=None,
                work_type="ремонт",
                description=description,
                due_date=None,
                items=[(display_item, qty, 0.0)],
                created_by=0,
            )
        except Exception as e:
            logger.exception("bus order create failed")
            results.append({"external_ref": external_ref, "error": str(e)})
            continue

        order = q("SELECT id, number, status FROM orders WHERE id=?", (oid,), one=True)
        file_bus.write_repair_status(
            external_ref=external_ref,
            status=order["status"] if order else "принят",
            order_number=order["number"] if order else "",
            order_id=oid,
            message="Заявка принята из файловой шины",
        )
        file_bus.mark_done(path)
        results.append({
            "external_ref": external_ref,
            "duplicate": False,
            "id": oid,
            "number": order["number"] if order else "",
            "status": order["status"] if order else "принят",
        })
        logger.info("Bus file request accepted: %s -> %s", external_ref, order["number"] if order else oid)

    return results


def push_status_for_order(order: dict) -> None:
    """При смене статуса заказа с [BUS:…] — записать JSON в to_tkan/."""
    import file_bus

    ref = extract_external_ref(order.get("description"))
    if not ref:
        return
    try:
        file_bus.write_repair_status(
            external_ref=ref,
            status=order.get("status") or "",
            order_number=order.get("number") or "",
            order_id=order.get("id"),
            total=float(order.get("total") or 0),
            message=f"Статус в ателье: {order.get('status') or ''}",
        )
        logger.info("Bus file status written: ref=%s status=%s", ref, order.get("status"))
    except Exception:
        logger.exception("Bus file status write failed")
