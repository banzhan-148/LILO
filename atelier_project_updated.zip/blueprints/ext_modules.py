"""UI для внешних модулей Ателье: карта мерок, карта местонахождения, карта загрузки."""
from __future__ import annotations

import logging

from flask import Blueprint, render_template, request, redirect, url_for, flash

from db import q
from utils import (login_required, role_required, clean_text, safe_int,
                   current_user, log_action)
from modules.measure_card import MeasureCardModule
from modules.location_map import LocationMapModule, ZONES
from modules.workload_map import WorkloadMapModule

logger = logging.getLogger(__name__)
bp = Blueprint('ext_modules', __name__, url_prefix='/modules')


@bp.route('/')
@login_required
@role_required('admin', 'receptionist', 'director', 'worker')
def index():
    """Список внешних модулей."""
    modules = [
        {'code': m.code, 'name': m.name, 'description': m.description, 'url': url_for(ep)}
        for m, ep in (
            (MeasureCardModule, 'ext_modules.measure_page'),
            (LocationMapModule, 'ext_modules.location_page'),
            (WorkloadMapModule, 'ext_modules.workload_page'),
        )
    ]
    return render_template('modules/index.html', modules=modules)


# ---------- 1. Карта мерок ----------
@bp.route('/measure')
@login_required
@role_required('admin', 'receptionist', 'director')
def measure_page():
    clients = q('SELECT id, full_name, phone FROM clients WHERE is_deleted=0 '
                'ORDER BY full_name LIMIT 500')
    client_id = safe_int(request.args.get('client_id'), 0)
    client, card, history = None, None, []
    if client_id:
        client = q('SELECT * FROM clients WHERE id=? AND is_deleted=0', (client_id,), one=True)
        if client:
            history = q('SELECT * FROM measurements WHERE client_id=? '
                        'ORDER BY taken_at DESC, id DESC LIMIT 10', (client_id,))
            mod = MeasureCardModule()
            card = mod.build_card(history[0] if history else None,
                                  history[1] if len(history) > 1 else None)
            log_action('Внешний модуль: карта мерок', 'client', client_id)
        else:
            flash('Клиент не найден', 'error')
    return render_template(
        'modules/measure.html', module_name=MeasureCardModule.name,
        clients=clients, client=client, card=card, history_count=len(history),
    )


# ---------- 2. Карта местонахождения ----------
@bp.route('/location', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'receptionist', 'worker', 'director')
def location_page():
    mod = LocationMapModule()
    if request.method == 'POST':
        user = current_user()
        if user['role'] == 'director':
            flash('Директор может только просматривать карту', 'error')
            return redirect(url_for('ext_modules.location_page'))
        res = mod.move(
            order_id=safe_int(request.form.get('order_id'), 0),
            zone=clean_text(request.form.get('zone'), 32),
            note=clean_text(request.form.get('note'), 255),
            user_id=user['id'],
        )
        if res['ok']:
            flash(res['message'], 'success')
            log_action('Внешний модуль: перемещение заказа',
                       'order', safe_int(request.form.get('order_id'), 0))
        else:
            flash(res['error'], 'error')
        return redirect(url_for('ext_modules.location_page'))

    zones = mod.zones_with_orders()
    positions = mod.current_positions()
    return render_template(
        'modules/location.html', module_name=LocationMapModule.name,
        zones=zones, zone_list=ZONES, unplaced=mod.unplaced(),
        orders=list(positions.values()), history=mod.history(15),
    )


# ---------- 3. Карта загрузки ----------
@bp.route('/workload')
@login_required
@role_required('admin', 'receptionist', 'director')
def workload_page():
    days = safe_int(request.args.get('days'), 14, min_val=3, max_val=31)
    data = WorkloadMapModule().build(days)
    return render_template('modules/workload.html',
                           module_name=WorkloadMapModule.name, data=data)
