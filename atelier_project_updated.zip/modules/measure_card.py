"""
Внешний модуль: карта мерок клиента.

Берёт последние мерки из таблицы measurements и раскладывает их по точкам
силуэта фигуры (SVG рисуется на странице, без внешних картинок).
"""
from __future__ import annotations

import json
from typing import Any

# Точки на силуэте: ключ → (подпись, x, y, возможные ключи в JSON мерок)
POINTS: list[dict[str, Any]] = [
    {'key': 'height', 'label': 'Рост', 'x': 40, 'y': 150, 'side': 'l',
     'aliases': ('рост', 'height')},
    {'key': 'neck', 'label': 'Обхват шеи', 'x': 150, 'y': 78, 'side': 'r',
     'aliases': ('обхват_шеи', 'шея', 'neck')},
    {'key': 'shoulders', 'label': 'Ширина плеч', 'x': 82, 'y': 100, 'side': 'l',
     'aliases': ('ширина_плеч', 'плечи', 'shoulders')},
    {'key': 'chest', 'label': 'Обхват груди', 'x': 218, 'y': 135, 'side': 'r',
     'aliases': ('обхват_груди', 'грудь', 'chest', 'bust')},
    {'key': 'waist', 'label': 'Обхват талии', 'x': 82, 'y': 190, 'side': 'l',
     'aliases': ('обхват_талии', 'талия', 'waist')},
    {'key': 'hips', 'label': 'Обхват бёдер', 'x': 218, 'y': 235, 'side': 'r',
     'aliases': ('обхват_бёдер', 'обхват_бедер', 'бёдра', 'бедра', 'hips')},
    {'key': 'sleeve', 'label': 'Длина рукава', 'x': 82, 'y': 270, 'side': 'l',
     'aliases': ('длина_рукава', 'рукав', 'sleeve')},
    {'key': 'inseam', 'label': 'Длина по внутр. шву', 'x': 218, 'y': 340, 'side': 'r',
     'aliases': ('длина_по_внутреннему_шву', 'внутренний_шов', 'inseam')},
]


class MeasureCardModule:
    """Карта мерок: привязка числовых значений к точкам силуэта."""

    name = 'Карта мерок'
    code = 'measure_card'
    description = (
        'Силуэт фигуры с отмеченными точками замеров: рост, грудь, талия, бёдра и др. '
        'Показывает последние мерки клиента и динамику по сравнению с предыдущими.'
    )

    @staticmethod
    def parse(row: dict[str, Any] | None) -> dict[str, Any]:
        if not row:
            return {}
        try:
            data = json.loads(row.get('data_json') or '{}')
        except (TypeError, ValueError):
            return {}
        return data if isinstance(data, dict) else {}

    @staticmethod
    def _find(data: dict[str, Any], aliases: tuple[str, ...]) -> Any:
        low = {str(k).strip().lower(): v for k, v in data.items()}
        for a in aliases:
            if a in low and low[a] not in (None, ''):
                return low[a]
        return None

    @staticmethod
    def _num(v: Any) -> float | None:
        try:
            return float(str(v).replace(',', '.'))
        except (TypeError, ValueError):
            return None

    def build_card(
        self,
        latest: dict[str, Any] | None,
        previous: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Собрать карту: точки с значениями, дельтой и «прочие» параметры."""
        cur = self.parse(latest)
        prev = self.parse(previous)
        used: set[str] = set()
        points = []
        for p in POINTS:
            val = self._find(cur, p['aliases'])
            old = self._find(prev, p['aliases'])
            delta = None
            a, b = self._num(val), self._num(old)
            if a is not None and b is not None and a != b:
                delta = round(a - b, 1)
            for al in p['aliases']:
                used.add(al)
            points.append({**{k: p[k] for k in ('key', 'label', 'x', 'y', 'side')},
                           'value': val, 'delta': delta})
        other = {k: v for k, v in cur.items()
                 if str(k).strip().lower() not in used}
        filled = sum(1 for p in points if p['value'] is not None)
        return {
            'taken_at': (latest or {}).get('taken_at') or '',
            'note': (latest or {}).get('note') or '',
            'points': points,
            'other': other,
            'filled': filled,
            'total': len(points),
            'has_data': bool(cur),
        }
