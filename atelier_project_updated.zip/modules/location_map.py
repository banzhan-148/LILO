"""
Внешний модуль: карта местонахождения заказов.

Схема ателье с зонами (приёмка, раскрой, пошив и т.д.). Для каждого заказа
хранится история перемещений в таблице order_locations; текущая зона — последняя запись.
"""
from __future__ import annotations

from typing import Any

from db import q, execute

# code → (название, x, y, ширина, высота) на схеме 640×360
ZONES: list[dict[str, Any]] = [
    {'code': 'reception', 'name': 'Приёмка', 'x': 20, 'y': 20, 'w': 190, 'h': 130},
    {'code': 'cutting', 'name': 'Раскрой', 'x': 225, 'y': 20, 'w': 190, 'h': 130},
    {'code': 'sewing', 'name': 'Пошивочный цех', 'x': 430, 'y': 20, 'w': 190, 'h': 200},
    {'code': 'fitting', 'name': 'Примерочная', 'x': 20, 'y': 165, 'w': 190, 'h': 175},
    {'code': 'pressing', 'name': 'Глажка / отделка', 'x': 225, 'y': 165, 'w': 190, 'h': 175},
    {'code': 'pickup', 'name': 'Выдача', 'x': 430, 'y': 235, 'w': 190, 'h': 105},
]
ZONE_CODES = {z['code'] for z in ZONES}
ZONE_NAMES = {z['code']: z['name'] for z in ZONES}

# Зона по умолчанию для заказа, у которого ещё нет перемещений
DEFAULT_BY_STATUS = {
    'принят': 'reception',
    'в работе': 'sewing',
    'на примерке': 'fitting',
    'готов': 'pickup',
    'выдан': None,
    'отменён': None,
}


class LocationMapModule:
    """Где сейчас лежит заказ."""

    name = 'Карта местонахождения заказов'
    code = 'location_map'
    description = (
        'Схема ателье по зонам: приёмка, раскрой, пошив, примерочная, глажка, выдача. '
        'Показывает, где физически находится каждый заказ, и хранит историю перемещений.'
    )

    def current_positions(self) -> dict[int, dict[str, Any]]:
        """Текущая зона для каждого активного заказа."""
        orders = q(
            """SELECT o.id, o.number, o.status, o.due_date, c.full_name AS client_name
               FROM orders o LEFT JOIN clients c ON c.id = o.client_id
               WHERE o.is_deleted=0 AND o.status NOT IN ('выдан','отменён')
               ORDER BY o.id DESC LIMIT 200"""
        )
        last = {
            r['order_id']: r for r in q(
                """SELECT l.order_id, l.zone, l.moved_at, l.note
                   FROM order_locations l
                   JOIN (SELECT order_id, MAX(id) mid FROM order_locations GROUP BY order_id) m
                     ON m.mid = l.id"""
            )
        }
        out: dict[int, dict[str, Any]] = {}
        for o in orders:
            rec = last.get(o['id'])
            zone = rec['zone'] if rec else DEFAULT_BY_STATUS.get(o['status'])
            out[o['id']] = {
                **o,
                'zone': zone if zone in ZONE_CODES else None,
                'moved_at': rec['moved_at'] if rec else '',
                'note': rec['note'] if rec else '',
                'tracked': bool(rec),
            }
        return out

    def zones_with_orders(self) -> list[dict[str, Any]]:
        positions = self.current_positions()
        zones = []
        for z in ZONES:
            items = [p for p in positions.values() if p['zone'] == z['code']]
            zones.append({**z, 'orders': items, 'count': len(items)})
        return zones

    def unplaced(self) -> list[dict[str, Any]]:
        return [p for p in self.current_positions().values() if not p['zone']]

    def move(self, order_id: int, zone: str, note: str = '', user_id: int | None = None) -> dict[str, Any]:
        if zone not in ZONE_CODES:
            return {'ok': False, 'error': 'Неизвестная зона'}
        order = q('SELECT id, number FROM orders WHERE id=? AND is_deleted=0', (order_id,), one=True)
        if not order:
            return {'ok': False, 'error': 'Заказ не найден'}
        execute(
            'INSERT INTO order_locations (order_id, zone, note, moved_by) VALUES (?, ?, ?, ?)',
            (order_id, zone, note, user_id),
        )
        return {'ok': True, 'message': f"Заказ {order['number']} → {ZONE_NAMES[zone]}"}

    def history(self, limit: int = 20) -> list[dict[str, Any]]:
        rows = q(
            """SELECT l.zone, l.note, l.moved_at, o.number, u.full_name AS user_name
               FROM order_locations l
               JOIN orders o ON o.id = l.order_id
               LEFT JOIN users u ON u.id = l.moved_by
               ORDER BY l.id DESC LIMIT ?""",
            (limit,),
        )
        for r in rows:
            r['zone_name'] = ZONE_NAMES.get(r['zone'], r['zone'])
        return rows
