"""
Внешний модуль: карта загрузки мастеров.

Тепловая карта «мастер × день»: сколько активных заказов у каждого исполнителя
со сроком сдачи в этот день. Просроченные заказы выделяются отдельной колонкой.
"""
from __future__ import annotations

from datetime import date, timedelta
from typing import Any

from db import q


class WorkloadMapModule:
    """Загрузка исполнителей по срокам."""

    name = 'Карта загрузки мастеров'
    code = 'workload_map'
    description = (
        'Тепловая карта: исполнители по строкам, ближайшие дни по столбцам. '
        'Видно, у кого сколько заказов на какой срок, кто перегружен и что просрочено.'
    )

    def build(self, days: int = 14, today: date | None = None) -> dict[str, Any]:
        today = today or date.today()
        days = max(3, min(int(days), 31))
        dates = [today + timedelta(days=i) for i in range(days)]
        end = dates[-1]

        workers = q('SELECT id, full_name, specialization FROM workers WHERE is_active=1 ORDER BY full_name')
        rows = q(
            """SELECT worker_id, due_date FROM orders
               WHERE is_deleted=0 AND status IN ('принят','в работе','на примерке')"""
        )

        index = {w['id']: {'worker': w, 'cells': [0] * days, 'overdue': 0,
                           'later': 0, 'nodate': 0} for w in workers}
        index[None] = {'worker': {'id': None, 'full_name': 'Не назначен', 'specialization': ''},
                       'cells': [0] * days, 'overdue': 0, 'later': 0, 'nodate': 0}

        for r in rows:
            slot = index.get(r['worker_id']) or index[None]
            raw = (r.get('due_date') or '')[:10]
            try:
                d = date.fromisoformat(raw)
            except ValueError:
                slot['nodate'] += 1
                continue
            if d < today:
                slot['overdue'] += 1
            elif d > end:
                slot['later'] += 1
            else:
                slot['cells'][(d - today).days] += 1

        table = []
        peak = 0
        for slot in index.values():
            total = sum(slot['cells']) + slot['overdue'] + slot['later'] + slot['nodate']
            if slot['worker']['id'] is None and total == 0:
                continue
            peak = max(peak, max(slot['cells'], default=0))
            table.append({**slot, 'total': total})

        for slot in table:
            slot['cells'] = [{'n': n, 'level': self.level(n, peak)} for n in slot['cells']]

        return {
            'dates': [{'iso': d.isoformat(), 'label': d.strftime('%d.%m'),
                       'weekend': d.weekday() >= 5, 'today': d == today} for d in dates],
            'rows': table,
            'peak': peak,
            'days': days,
        }

    @staticmethod
    def level(n: int, peak: int) -> int:
        """0..4 — интенсивность заливки ячейки."""
        if n <= 0 or peak <= 0:
            return 0
        return min(4, max(1, round(4 * n / peak)))
