"""
Внешние модули АИС «Ателье».

Подключаются как отдельные пакеты (не смешиваются с core services).
Все три модуля — «карты»: визуальные представления данных ателье.
"""
from modules.measure_card import MeasureCardModule
from modules.location_map import LocationMapModule
from modules.workload_map import WorkloadMapModule

__all__ = ['MeasureCardModule', 'LocationMapModule', 'WorkloadMapModule']
