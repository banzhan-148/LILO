"""
Файловая шина обмена (JSON) между Ткань и Ателье.

Оба проекта должны указывать на ОДНУ папку BUS_DIR
(общая сетевая папка, например рядом с проектами: ../bus).

Структура:
  BUS_DIR/
    to_atelier/   <- Ткань пишет заявки на ремонт
    to_tkan/      <- Ателье пишет статусы
    done/         <- обработанные сообщения (архив)

Формат заявки (to_atelier/<external_ref>.json):
  {
    "type": "repair_request",
    "external_ref": "tkan-order-1-...",
    "created_at": "...",
    "customer": {"name": "...", "phone": "...", "email": ""},
    "item": {"name": "...", "size": "...", "qty": 1},
    "defect": "...",
    "note": "..."
  }

Формат статуса (to_tkan/<external_ref>.json):
  {
    "type": "repair_status",
    "external_ref": "...",
    "status": "в работе",
    "order_number": "AT-2026-00001",
    "order_id": 1,
    "total": 0,
    "message": "",
    "updated_at": "..."
  }
"""
from __future__ import annotations

import json
import os
import re
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


def _default_bus_dir() -> str:
    # .../tkan or .../atelier -> sibling folder "bus"
    here = Path(__file__).resolve().parent
    return str((here.parent / "bus").resolve())


def get_bus_dir() -> Path:
    raw = _default_bus_dir()
    # 1) config.py BUS_DIR
    try:
        import config as _cfg
        raw = getattr(_cfg, "BUS_DIR", None) or getattr(getattr(_cfg, "BaseConfig", object), "BUS_DIR", raw) or raw
        # atelier: Config class
        if hasattr(_cfg, "Config") and hasattr(_cfg.Config, "BUS_DIR"):
            raw = _cfg.Config.BUS_DIR
        if hasattr(_cfg, "BaseConfig") and hasattr(_cfg.BaseConfig, "BUS_DIR"):
            raw = _cfg.BaseConfig.BUS_DIR
    except Exception:
        pass
    # 2) flask app config
    try:
        from flask import current_app
        if current_app and current_app.config.get("BUS_DIR"):
            raw = current_app.config.get("BUS_DIR")
    except Exception:
        pass
    # 3) env
    raw = os.environ.get("BUS_DIR", raw)
    path = Path(raw)
    for sub in ("to_atelier", "to_tkan", "done"):
        (path / sub).mkdir(parents=True, exist_ok=True)
    return path


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def _safe_name(name: str) -> str:
    name = re.sub(r"[^\w.\-]+", "_", name, flags=re.UNICODE)
    return name[:120] or "msg"


def _atomic_write(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=str(path.parent), suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n")
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def write_repair_request(
    *,
    external_ref: str,
    customer_name: str,
    customer_phone: str = "",
    customer_email: str = "",
    item_name: str,
    item_size: str = "",
    item_qty: int = 1,
    defect: str,
    note: str = "",
) -> Path:
    """Ткань → Ателье: положить заявку на ремонт в to_atelier/."""
    bus = get_bus_dir()
    payload = {
        "type": "repair_request",
        "external_ref": external_ref,
        "created_at": _now(),
        "customer": {
            "name": customer_name,
            "phone": customer_phone or "",
            "email": customer_email or "",
        },
        "item": {
            "name": item_name,
            "size": item_size or "",
            "qty": int(item_qty or 1),
        },
        "defect": defect,
        "note": note or "",
    }
    path = bus / "to_atelier" / f"{_safe_name(external_ref)}.json"
    _atomic_write(path, payload)
    return path


def list_repair_requests() -> list[tuple[Path, dict[str, Any]]]:
    """Ателье: прочитать все заявки из to_atelier/."""
    bus = get_bus_dir()
    out: list[tuple[Path, dict[str, Any]]] = []
    folder = bus / "to_atelier"
    if not folder.is_dir():
        return out
    for path in sorted(folder.glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("type") == "repair_request":
                out.append((path, data))
        except Exception:
            continue
    return out


def mark_done(path: Path, sub: str = "done") -> None:
    """Перенести обработанный файл в done/."""
    bus = get_bus_dir()
    dest_dir = bus / sub
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / path.name
    if dest.exists():
        dest = dest_dir / f"{path.stem}_{_now().replace(':', '')}{path.suffix}"
    try:
        shutil.move(str(path), str(dest))
    except Exception:
        try:
            path.unlink()
        except OSError:
            pass


def write_repair_status(
    *,
    external_ref: str,
    status: str,
    order_number: str = "",
    order_id: int | None = None,
    total: float = 0,
    message: str = "",
) -> Path:
    """Ателье → Ткань: статус ремонта в to_tkan/."""
    bus = get_bus_dir()
    payload = {
        "type": "repair_status",
        "external_ref": external_ref,
        "status": status,
        "order_number": order_number or "",
        "order_id": order_id,
        "total": float(total or 0),
        "message": message or "",
        "updated_at": _now(),
    }
    path = bus / "to_tkan" / f"{_safe_name(external_ref)}.json"
    _atomic_write(path, payload)
    return path


def read_repair_status(external_ref: str) -> dict[str, Any] | None:
    """Ткань: прочитать статус по external_ref из to_tkan/."""
    bus = get_bus_dir()
    path = bus / "to_tkan" / f"{_safe_name(external_ref)}.json"
    if not path.is_file():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return data
    except Exception:
        return None
    return None


def list_repair_statuses() -> list[dict[str, Any]]:
    """Ткань: все статусы из to_tkan/."""
    bus = get_bus_dir()
    out: list[dict[str, Any]] = []
    folder = bus / "to_tkan"
    if not folder.is_dir():
        return out
    for path in folder.glob("*.json"):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and data.get("type") == "repair_status":
                out.append(data)
        except Exception:
            continue
    return out
