"""
Шина обмена данными: внешние системы → Ателье.

Сейчас поддерживается один поток:
  Магазин «Ткань» принимает брак и создаёт заявку на ремонт.

Аутентификация: заголовок X-Bus-Key (общий секрет BUS_API_KEY).
CSRF для этих маршрутов отключён (машинный API).
"""
from __future__ import annotations

import logging
import re
from functools import wraps

from flask import Blueprint, jsonify, request, current_app

from extensions import csrf, limiter
from db import q, execute, transaction
from services.orders import OrderService
from services.clients import ClientService

logger = logging.getLogger(__name__)

bp = Blueprint('bus_api', __name__, url_prefix='/api/bus/v1')


def _require_bus_key(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        expected = current_app.config.get('BUS_API_KEY') or ''
        got = request.headers.get('X-Bus-Key', '')
        if not expected or got != expected:
            logger.warning('Bus API: invalid or missing X-Bus-Key from %s', request.remote_addr)
            return jsonify({'ok': False, 'error': 'unauthorized'}), 401
        return f(*args, **kwargs)
    return wrapper


def _clean(s: str | None, max_len: int = 500) -> str:
    if not s:
        return ''
    s = re.sub(r'\s+', ' ', str(s)).strip()
    return s[:max_len]


@bp.route('/repair', methods=['POST'])
@csrf.exempt
@limiter.limit('30 per minute')
@_require_bus_key
def create_repair():
    """
    Создать заказ на ремонт по заявке из магазина.

    JSON body:
    {
      "external_ref": "tkan-order-42",     # обязательный уникальный ключ отправителя
      "source": "tkan",
      "customer": {
        "name": "Иван Иванов",
        "phone": "+79001234567",
        "email": "ivan@example.com"
      },
      "item": {
        "name": "Куртка демисезонная",
        "size": "M",
        "qty": 1
      },
      "defect": "Оторвалась молния, пятно на рукаве",
      "note": "Клиент вернул через пункт выдачи"
    }
    """
    data = request.get_json(silent=True) or {}

    external_ref = _clean(data.get('external_ref'), 64)
    if not external_ref:
        return jsonify({'ok': False, 'error': 'external_ref_required'}), 400

    # Идемпотентность: повторный запрос с тем же external_ref не создаёт дубликат
    existing = q(
        "SELECT id, number, status FROM orders "
        "WHERE is_deleted=0 AND description LIKE ?",
        (f'%[BUS:{external_ref}]%',),
        one=True,
    )
    if existing:
        return jsonify({
            'ok': True,
            'duplicate': True,
            'order_id': existing['id'],
            'order_number': existing['number'],
            'status': existing['status'],
        })

    customer = data.get('customer') or {}
    item = data.get('item') or {}
    defect = _clean(data.get('defect'), 1000)
    note = _clean(data.get('note'), 500)
    source = _clean(data.get('source') or 'external', 32)

    name = _clean(customer.get('name'), 120)
    phone = _clean(customer.get('phone'), 32)
    email = _clean(customer.get('email'), 120)

    if not name:
        return jsonify({'ok': False, 'error': 'customer_name_required'}), 400
    if not defect:
        return jsonify({'ok': False, 'error': 'defect_required'}), 400

    item_name = _clean(item.get('name'), 200) or 'Изделие (без названия)'
    size = _clean(item.get('size'), 32)
    try:
        qty = max(1, int(item.get('qty') or 1))
    except (TypeError, ValueError):
        qty = 1

    display_item = f'{item_name}' + (f' ({size})' if size else '')

    # Клиент: ищем по телефону или имени, иначе создаём
    client_id = None
    if phone:
        row = q(
            "SELECT id FROM clients WHERE is_deleted=0 AND phone=? LIMIT 1",
            (phone,),
            one=True,
        )
        if row:
            client_id = row['id']
    if client_id is None:
        try:
            client_id = ClientService.create(
                full_name=name,
                phone=phone,
                email=email,
            )
        except ValueError as e:
            msg = str(e)
            if msg.startswith('duplicate:'):
                client_id = int(msg.split(':', 1)[1])
            else:
                return jsonify({'ok': False, 'error': msg}), 400

    description_parts = [
        f'[BUS:{external_ref}]',
        f'Источник: {source}',
        f'Дефект: {defect}',
    ]
    if note:
        description_parts.append(f'Примечание: {note}')
    description = '\n'.join(description_parts)

    # created_by = 0 — системная заявка по шине (нет пользователя-оператора)
    try:
        oid = OrderService.create(
            client_id=client_id,
            worker_id=None,
            work_type='ремонт',
            description=description,
            due_date=None,
            items=[(display_item, qty, 0.0)],
            created_by=0,
        )
    except Exception as e:
        logger.exception('Bus repair create failed')
        return jsonify({'ok': False, 'error': 'create_failed', 'detail': str(e)}), 500

    order = q('SELECT id, number, status, total FROM orders WHERE id=?', (oid,), one=True)
    logger.info(
        'Bus repair created: external_ref=%s order=%s client_id=%s',
        external_ref, order['number'] if order else oid, client_id,
    )
    return jsonify({
        'ok': True,
        'duplicate': False,
        'order_id': order['id'],
        'order_number': order['number'],
        'status': order['status'],
        'client_id': client_id,
    }), 201


@bp.route('/repair/<path:external_ref>', methods=['GET'])
@csrf.exempt
@limiter.limit('60 per minute')
@_require_bus_key
def get_repair_status(external_ref: str):
    """Статус заявки по внешнему ключу (например tkan-order-42)."""
    external_ref = _clean(external_ref, 64)
    if not external_ref:
        return jsonify({'ok': False, 'error': 'external_ref_required'}), 400

    order = q(
        "SELECT id, number, status, total, paid, created_at, description "
        "FROM orders WHERE is_deleted=0 AND description LIKE ? "
        "ORDER BY id DESC LIMIT 1",
        (f'%[BUS:{external_ref}]%',),
        one=True,
    )
    if not order:
        return jsonify({'ok': False, 'error': 'not_found'}), 404

    return jsonify({
        'ok': True,
        'order_id': order['id'],
        'order_number': order['number'],
        'status': order['status'],
        'total': order['total'],
        'paid': order['paid'],
        'created_at': order['created_at'],
    })
