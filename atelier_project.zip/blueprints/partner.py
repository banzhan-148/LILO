"""
Партнёрская шина «Ателье» ↔ «Ткань».

Обеспечивает:
- страницу партнёра (/partner)
- редирект «Перейти к партнёру» (/go-partner) с UTM/ref
"""
from __future__ import annotations

from urllib.parse import urlencode, urlparse, urlunparse, parse_qs

from flask import Blueprint, render_template, redirect, request, current_app, session, g

partner_bp = Blueprint("partner", __name__)


def _partner_cfg() -> dict:
    return {
        "name": current_app.config.get("PARTNER_NAME", "Интернет-магазин «Ткань»"),
        "url": current_app.config.get("PARTNER_URL", "http://127.0.0.1:8080"),
        "short": current_app.config.get("PARTNER_SHORT", "Ткань"),
        "desc": current_app.config.get(
            "PARTNER_DESC",
            "Партнёрский интернет-магазин готовой одежды. Каталог, доставка, отзывы.",
        ),
        "cta": current_app.config.get("PARTNER_CTA", "Нужна готовая одежда?"),
    }


@partner_bp.route("/partner")
def partner_page():
    """Информационная страница о партнёре + кнопка перехода."""
    cfg = _partner_cfg()
    return render_template("partner.html", partner=cfg)


@partner_bp.route("/go-partner")
def go_partner():
    """
    Редирект на партнёра с метками.
    /go-partner?from=orders → партнёр получит utm_source=atelier&...
    """
    cfg = _partner_cfg()
    target = cfg["url"].rstrip("/")

    path = request.args.get("path", "/")
    if not path.startswith("/"):
        path = "/" + path

    source = request.args.get("from", "site")
    session["last_partner_click"] = source

    params = {
        "utm_source": "atelier",
        "utm_medium": "partner_bus",
        "utm_campaign": source,
        "ref": "atelier",
    }
    for key in ("order_id", "client_id", "user_hint"):
        val = request.args.get(key)
        if val and len(val) < 64:
            params[key] = val

    parsed = urlparse(target + path)
    q = parse_qs(parsed.query)
    for k, v in params.items():
        q[k] = [v]
    new_query = urlencode({k: v[0] for k, v in q.items()})
    final = urlunparse(parsed._replace(query=new_query))
    return redirect(final, code=302)
