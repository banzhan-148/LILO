"""
Клиент шины: Ателье → Ткань.

Отправляет обновления статуса ремонта обратно в магазин.
"""
from __future__ import annotations

import json
import logging
import re
import urllib.error
import urllib.request
from typing import Any

from flask import current_app

logger = logging.getLogger(__name__)

# [BUS:external_ref] в description заказа
_BUS_REF_RE = re.compile(r"\[BUS:([^\]]+)\]")


def extract_external_ref(description: str | None) -> str | None:
    if not description:
        return None
    m = _BUS_REF_RE.search(description)
    return m.group(1).strip() if m else None


def _request(method: str, path: str, body: dict | None = None, timeout: float = 6.0) -> dict[str, Any]:
    base = (current_app.config.get("BUS_TKAN_URL") or "http://127.0.0.1:8080").rstrip("/")
    key = current_app.config.get("BUS_API_KEY") or ""
    url = base + path
    data = None
    headers = {
        "X-Bus-Key": key,
        "Accept": "application/json",
        "User-Agent": "AtelierBusClient/1.0",
    }
    if body is not None:
        data = json.dumps(body, ensure_ascii=False).encode("utf-8")
        headers["Content-Type"] = "application/json; charset=utf-8"

    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8")
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        try:
            payload = json.loads(e.read().decode("utf-8"))
        except Exception:
            payload = {}
        logger.warning("Bus → Tkan HTTP %s: %s", e.code, payload)
        return {"ok": False, "error": payload.get("error") or f"HTTP {e.code}"}
    except Exception as e:
        logger.warning("Bus → Tkan failed: %s", e)
        return {"ok": False, "error": str(e)}


def notify_repair_status(
    *,
    external_ref: str,
    status: str,
    order_number: str = "",
    order_id: int | None = None,
) -> dict[str, Any]:
    """Обычное обновление статуса (принят / в работе / на примерке …)."""
    return _request("POST", "/api/bus/v1/repair-status", body={
        "external_ref": external_ref,
        "status": status,
        "order_number": order_number,
        "order_id": order_id,
    })


def notify_repair_done(
    *,
    external_ref: str,
    status: str,
    order_number: str = "",
    order_id: int | None = None,
    total: float = 0,
    message: str = "",
) -> dict[str, Any]:
    """Ремонт готов или выдан — с возможной стоимостью и комментарием."""
    return _request("POST", "/api/bus/v1/repair-done", body={
        "external_ref": external_ref,
        "status": status,
        "order_number": order_number,
        "order_id": order_id,
        "total": total,
        "message": message,
    })


def push_status_for_order(order: dict) -> None:
    """
    Если заказ пришёл по шине ([BUS:…]), отправить статус в Ткань.
    Для «готов» / «выдан» — repair-done, иначе repair-status.
    Ошибки только логируются, чтобы не ломать UI ателье.
    """
    ref = extract_external_ref(order.get("description"))
    if not ref:
        return

    status = order.get("status") or ""
    number = order.get("number") or ""
    oid = order.get("id")
    total = float(order.get("total") or 0)

    if status in ("готов", "выдан"):
        result = notify_repair_done(
            external_ref=ref,
            status=status,
            order_number=number,
            order_id=oid,
            total=total,
            message=f"Статус в ателье: {status}",
        )
    else:
        result = notify_repair_status(
            external_ref=ref,
            status=status,
            order_number=number,
            order_id=oid,
        )

    if result.get("ok"):
        logger.info("Bus notified Tkan: ref=%s status=%s", ref, status)
    else:
        logger.warning("Bus notify Tkan failed: ref=%s err=%s", ref, result.get("error"))
