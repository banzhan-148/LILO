# Файл секретов. В реальном проекте — .env и python-dotenv.
# Здесь — потому что в учебной среде .env создать нельзя.
#
# ⚠️ Не выкладывайте этот файл в публичный git!

# Сгенерируйте свой: python -c "import secrets; print(secrets.token_hex(32))"
SECRET_KEY = "b1ad302e4ecabccb14da5a8badf807fc0ec125c508ab7366bce2ad5875ce408d2"

# Пароль администратора — смените на свой!
ADMIN_PASSWORD = "Qwerty!2026Admin"

# --- Партнёрская шина (Ткань ↔ Ателье) ---
# URL партнёра. В продакшене замените на реальный домен.
PARTNER_URL = "http://127.0.0.1:5000"
PARTNER_NAME = "АИС «Ателье»"
PARTNER_SHORT = "Ателье"
PARTNER_DESC = "Партнёрский сервис пошива и ремонта одежды. Индивидуальные заказы, подгонка, ремонт."
PARTNER_CTA = "Нужен пошив или ремонт?"

# Общий секрет для API-шины (должен совпадать в обоих приложениях)
BUS_API_KEY = "tkan-atelier-bus-secret-2026-change-me"
# Базовый URL API ателье
BUS_ATELIER_URL = "http://127.0.0.1:5001"  # порт Ателье
