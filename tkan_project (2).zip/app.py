"""
Точка входа приложения «Ткань» — интернет-магазин одежды.

Реализован паттерн Application Factory: create_app() создаёт Flask-приложение,
подключает расширения, регистрирует Blueprints и обработчики ошибок.
"""
import time
import secrets
from flask import Flask, render_template, session, request, g

from config import (
    SECRET_KEY,
    PARTNER_URL,
    PARTNER_NAME,
    PARTNER_SHORT,
    PARTNER_DESC,
    PARTNER_CTA,
)
from constants import EM, CATS, TAGS, STATUSES
from db import init_db, close_db
from security import check_csrf
from helpers import current_user, wishlist_count

import metrics

from auth import auth_bp
from pages import pages_bp
from catalog import catalog_bp
from cart import cart_bp
from wishlist import wishlist_bp
from admin import admin_bp
from partner import partner_bp
from bus_api import bus_api_bp


def create_app() -> Flask:

    """Создаёт и настраивает Flask-приложение."""
    app = Flask(__name__)
    app.secret_key = SECRET_KEY
    app.config["MAX_CONTENT_LENGTH"] = 12 * 1024 * 1024
    # Партнёрская шина
    app.config["PARTNER_URL"] = PARTNER_URL
    app.config["PARTNER_NAME"] = PARTNER_NAME
    app.config["PARTNER_SHORT"] = PARTNER_SHORT
    app.config["PARTNER_DESC"] = PARTNER_DESC
    app.config["PARTNER_CTA"] = PARTNER_CTA


    app.teardown_appcontext(close_db)

    def _start_timer():
        g._start_ts = time.perf_counter()

    app.before_request(_start_timer)
    app.before_request(check_csrf)

    @app.after_request
    def _log_timing(response):
        if request.endpoint in ("static", "admin.admin_metrics_json"):
            return response
        started = getattr(g, "_start_ts", None)
        if started is None:
            return response
        ms = (time.perf_counter() - started) * 1000
        metrics.record(
            endpoint=request.endpoint or "(unknown)",
            path=request.path,
            method=request.method,
            status=response.status_code,
            ms=ms,
        )
        response.headers["X-Response-Time"] = f"{ms:.2f}ms"
        if response.mimetype == "text/html" and response.status_code < 500:
            try:
                badge = (
                    '<div style="position:fixed;bottom:10px;right:10px;'
                    'padding:5px 10px;background:#2F5BFF;color:#fff;'
                    'border-radius:8px;font:12px/1.4 monospace;'
                    'z-index:99999;opacity:.85;pointer-events:none">'
                    f'{ms:.1f} ms</div>'
                )
                body = response.get_data(as_text=True)
                if "</body>" in body:
                    response.set_data(body.replace("</body>", badge + "</body>", 1))
            except Exception:
                pass
        return response

    app.register_blueprint(auth_bp)
    app.register_blueprint(catalog_bp)
    app.register_blueprint(cart_bp)
    app.register_blueprint(wishlist_bp)
    app.register_blueprint(admin_bp)
    app.register_blueprint(pages_bp)
    app.register_blueprint(partner_bp)
    app.register_blueprint(bus_api_bp)


    @app.context_processor
    def common():
        session.setdefault("csrf", secrets.token_hex(16))
        return dict(
            csrf=session["csrf"],
            EM=EM, CATS=CATS, TAGS=TAGS, STATUSES=STATUSES,
            cart_count=sum(session.get("cart", {}).values()),
            wishlist_count=wishlist_count(),
            is_admin=session.get("admin", False),
            user=current_user(),
            partner_name=app.config.get("PARTNER_SHORT", "Ателье"),
            partner_cta=app.config.get("PARTNER_CTA", "Партнёр"),
        )


    @app.errorhandler(403)
    def forbidden(e):
        return render_template("errors/403.html"), 403

    @app.errorhandler(404)
    def not_found(e):
        return render_template("errors/404.html"), 404

    @app.errorhandler(429)
    def too_many(e):
        return render_template("errors/429.html"), 429

    return app


app = create_app()
init_db()


if __name__ == "__main__":
    print("Ткань: http://127.0.0.1:8080  |  шина → http://127.0.0.1:5001")
    app.run(debug=False, host="0.0.0.0", port=8080)