from datetime import datetime, timedelta
from flask import Blueprint, render_template, request, redirect, url_for, session, flash, jsonify
from .models import User
from .extensions import db

bp = Blueprint('auth', __name__)

MAX_FAILED = 5
LOCK_MINUTES = 15


@bp.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        if not username or not password:
            flash('Заполните все поля')
        elif len(username) > 80:
            flash('Слишком длинный логин')
        elif User.query.filter_by(username=username).first():
            flash('Пользователь уже существует')
        else:
            user = User(username=username)
            user.set_password(password)
            db.session.add(user)
            db.session.commit()
            return redirect(url_for('auth.login'))
    return render_template('auth/register.html')


@bp.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        user = User.query.filter_by(username=username).first()

        # rate limit / lockout
        now = datetime.utcnow()
        if user and user.locked_until and user.locked_until > now:
            remaining = int((user.locked_until - now).total_seconds())
            resp = render_template('auth/login.html')
            # return 429 with Retry-After for API-style checks
            from flask import make_response
            response = make_response(resp, 429)
            response.headers['Retry-After'] = str(max(remaining, 1))
            flash('Слишком много попыток. Попробуйте позже.')
            return response

        if user and user.check_password(password):
            user.failed_logins = 0
            user.locked_until = None
            db.session.commit()
            session['user_id'] = user.id
            return redirect(url_for('main.index'))

        # failed attempt
        if user:
            user.failed_logins = (user.failed_logins or 0) + 1
            if user.failed_logins >= MAX_FAILED:
                user.locked_until = now + timedelta(minutes=LOCK_MINUTES)
                user.failed_logins = 0
            db.session.commit()
            # small artificial delay to slow brute force
            import time
            time.sleep(0.35)

        flash('Неверные данные')
        # also sleep a bit even for non-existing users to avoid user enumeration timing
        if not user:
            import time
            time.sleep(0.35)
    return render_template('auth/login.html')


@bp.get('/logout')
def logout():
    session.pop('user_id', None)
    return redirect(url_for('main.index'))
