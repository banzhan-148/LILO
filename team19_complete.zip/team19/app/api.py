from flask import Blueprint, jsonify, request, session, current_app, send_file
from io import BytesIO
from datetime import datetime
from functools import wraps

from .extensions import db
from .models import User, Channel, ChannelMember, Chat, Message

bp = Blueprint('api', __name__)


def login_required_api(f):
    @wraps(f)
    def wrapped(*args, **kwargs):
        user_id = session.get('user_id')
        if not user_id:
            return jsonify({'error': 'unauthorized'}), 401
        user = User.query.get(user_id)
        if not user:
            session.pop('user_id', None)
            return jsonify({'error': 'unauthorized'}), 401
        return f(user, *args, **kwargs)
    return wrapped


def message_to_dict(msg):
    return {
        'id': msg.id,
        'text': msg.text,
        'sender_id': msg.sender_id,
        'sender': msg.sender.username if msg.sender else None,
        'chat_id': msg.chat_id,
        'channel_id': msg.channel_id,
        'created_at': msg.created_at.isoformat() if msg.created_at else None,
    }


def chat_to_dict(chat, current_user_id):
    other = chat.user2 if chat.user1_id == current_user_id else chat.user1
    return {
        'id': chat.id,
        'user1_id': chat.user1_id,
        'user2_id': chat.user2_id,
        'other_username': other.username if other else None,
        'created_at': chat.created_at.isoformat() if chat.created_at else None,
    }


def channel_to_dict(ch):
    return {
        'id': ch.id,
        'name': ch.name,
        'creator_id': ch.creator_id,
        'created_at': ch.created_at.isoformat() if ch.created_at else None,
    }


@bp.get('/health')
def health():
    return jsonify({
        'status': 'ok',
        'team_id': current_app.config['TEAM_ID'],
        'team_name': current_app.config['TEAM_NAME'],
    })


# ---- Channels ----

@bp.post('/channels')
@login_required_api
def create_channel(user):
    data = request.get_json(silent=True) or {}
    name = (data.get('name') or '').strip()
    if not name or len(name) > 120:
        return jsonify({'error': 'invalid name'}), 400
    if Channel.query.filter_by(name=name).first():
        return jsonify({'error': 'channel already exists'}), 400
    ch = Channel(name=name, creator_id=user.id)
    db.session.add(ch)
    db.session.flush()
    db.session.add(ChannelMember(channel_id=ch.id, user_id=user.id))
    db.session.commit()
    return jsonify(channel_to_dict(ch)), 201


@bp.get('/channels')
@login_required_api
def list_channels(user):
    channels = Channel.query.order_by(Channel.name).all()
    return jsonify([channel_to_dict(c) for c in channels])


@bp.post('/channels/<int:channel_id>/join')
@login_required_api
def join_channel(user, channel_id):
    ch = Channel.query.get(channel_id)
    if not ch:
        return jsonify({'error': 'not found'}), 404
    existing = ChannelMember.query.filter_by(channel_id=channel_id, user_id=user.id).first()
    if existing:
        return jsonify({'ok': True, 'already_member': True})
    db.session.add(ChannelMember(channel_id=channel_id, user_id=user.id))
    db.session.commit()
    return jsonify({'ok': True}), 201


# ---- Private chats ----

@bp.post('/chats')
@login_required_api
def create_chat(user):
    data = request.get_json(silent=True) or {}
    username = (data.get('username') or '').strip()
    if not username:
        return jsonify({'error': 'username required'}), 400
    other = User.query.filter_by(username=username).first()
    if not other:
        return jsonify({'error': 'user not found'}), 404
    if other.id == user.id:
        return jsonify({'error': 'cannot chat with yourself'}), 400

    u1, u2 = sorted([user.id, other.id])
    chat = Chat.query.filter_by(user1_id=u1, user2_id=u2).first()
    if chat:
        return jsonify(chat_to_dict(chat, user.id))
    chat = Chat(user1_id=u1, user2_id=u2)
    db.session.add(chat)
    db.session.commit()
    return jsonify(chat_to_dict(chat, user.id)), 201


@bp.get('/chats')
@login_required_api
def list_chats(user):
    chats = Chat.query.filter(
        (Chat.user1_id == user.id) | (Chat.user2_id == user.id)
    ).order_by(Chat.created_at.desc()).all()
    return jsonify([chat_to_dict(c, user.id) for c in chats])


# ---- Messages ----

@bp.post('/messages')
@login_required_api
def send_message(user):
    data = request.get_json(silent=True) or {}
    text = data.get('text')
    if text is None or not str(text).strip():
        return jsonify({'error': 'text required'}), 400
    text = str(text)

    chat_id = data.get('chat_id')
    channel_id = data.get('channel_id')

    if chat_id is not None and channel_id is not None:
        return jsonify({'error': 'specify either chat_id or channel_id'}), 400
    if chat_id is None and channel_id is None:
        return jsonify({'error': 'chat_id or channel_id required'}), 400

    if chat_id is not None:
        try:
            chat_id = int(chat_id)
        except (TypeError, ValueError):
            return jsonify({'error': 'invalid chat_id'}), 400
        chat = Chat.query.get(chat_id)
        if not chat:
            return jsonify({'error': 'chat not found'}), 404
        if user.id not in (chat.user1_id, chat.user2_id):
            return jsonify({'error': 'forbidden'}), 403
        msg = Message(text=text, sender_id=user.id, chat_id=chat.id)
    else:
        try:
            channel_id = int(channel_id)
        except (TypeError, ValueError):
            return jsonify({'error': 'invalid channel_id'}), 400
        ch = Channel.query.get(channel_id)
        if not ch:
            return jsonify({'error': 'channel not found'}), 404
        member = ChannelMember.query.filter_by(channel_id=channel_id, user_id=user.id).first()
        if not member:
            return jsonify({'error': 'forbidden'}), 403
        msg = Message(text=text, sender_id=user.id, channel_id=ch.id)

    db.session.add(msg)
    db.session.commit()
    return jsonify(message_to_dict(msg)), 201


@bp.get('/chats/<int:chat_id>/messages')
@login_required_api
def chat_messages(user, chat_id):
    chat = Chat.query.get(chat_id)
    if not chat:
        return jsonify({'error': 'not found'}), 404
    if user.id not in (chat.user1_id, chat.user2_id):
        return jsonify({'error': 'forbidden'}), 403
    msgs = Message.query.filter_by(chat_id=chat_id).order_by(Message.created_at.asc()).all()
    return jsonify([message_to_dict(m) for m in msgs])


@bp.get('/channels/<int:channel_id>/messages')
@login_required_api
def channel_messages(user, channel_id):
    ch = Channel.query.get(channel_id)
    if not ch:
        return jsonify({'error': 'not found'}), 404
    # any authenticated user can read public channel messages
    msgs = Message.query.filter_by(channel_id=channel_id).order_by(Message.created_at.asc()).all()
    return jsonify([message_to_dict(m) for m in msgs])


# ---- Search ----

@bp.get('/messages/search')
@login_required_api
def search_messages(user):
    q = (request.args.get('q') or '').strip()
    if not q:
        return jsonify([])

    # accessible chats
    chat_ids = [
        c.id for c in Chat.query.filter(
            (Chat.user1_id == user.id) | (Chat.user2_id == user.id)
        ).all()
    ]
    # accessible channels (member of)
    channel_ids = [
        m.channel_id for m in ChannelMember.query.filter_by(user_id=user.id).all()
    ]

    query = Message.query.filter(Message.text.contains(q))
    if chat_ids or channel_ids:
        from sqlalchemy import or_
        conditions = []
        if chat_ids:
            conditions.append(Message.chat_id.in_(chat_ids))
        if channel_ids:
            conditions.append(Message.channel_id.in_(channel_ids))
        query = query.filter(or_(*conditions))
    else:
        return jsonify([])

    msgs = query.order_by(Message.created_at.desc()).limit(100).all()
    return jsonify([message_to_dict(m) for m in msgs])


# ---- Profile ----

@bp.post('/profile')
@login_required_api
def update_profile(user):
    data = request.get_json(silent=True) or {}
    bio = data.get('bio')
    if bio is None:
        return jsonify({'error': 'bio required'}), 400
    user.bio = str(bio)[:2000]
    db.session.commit()
    return jsonify({'ok': True, 'bio': user.bio})


# ---- Export ----

ALLOWED_EXPORT_FORMATS = {'txt'}


@bp.get('/chats/<int:chat_id>/export')
@login_required_api
def export_chat(user, chat_id):
    fmt = (request.args.get('format') or 'txt').strip().lower()
    if fmt not in ALLOWED_EXPORT_FORMATS:
        return jsonify({'error': 'unsupported format'}), 400

    chat = Chat.query.get(chat_id)
    if not chat:
        return jsonify({'error': 'not found'}), 404
    if user.id not in (chat.user1_id, chat.user2_id):
        return jsonify({'error': 'forbidden'}), 403

    msgs = Message.query.filter_by(chat_id=chat_id).order_by(Message.created_at.asc()).all()
    lines = []
    for m in msgs:
        ts = m.created_at.strftime('%Y-%m-%d %H:%M:%S') if m.created_at else ''
        uname = m.sender.username if m.sender else str(m.sender_id)
        lines.append(f'[{ts}] {uname}: {m.text}')
    content = '\n'.join(lines) + ('\n' if lines else '')
    buf = BytesIO(content.encode('utf-8'))
    buf.seek(0)
    return send_file(
        buf,
        mimetype='text/plain; charset=utf-8',
        as_attachment=True,
        download_name=f'chat_{chat_id}.txt',
    )


@bp.get('/channels/<int:channel_id>/export')
@login_required_api
def export_channel(user, channel_id):
    fmt = (request.args.get('format') or 'txt').strip().lower()
    if fmt not in ALLOWED_EXPORT_FORMATS:
        return jsonify({'error': 'unsupported format'}), 400

    ch = Channel.query.get(channel_id)
    if not ch:
        return jsonify({'error': 'not found'}), 404
    # any authenticated can export public channel
    msgs = Message.query.filter_by(channel_id=channel_id).order_by(Message.created_at.asc()).all()
    lines = []
    for m in msgs:
        ts = m.created_at.strftime('%Y-%m-%d %H:%M:%S') if m.created_at else ''
        uname = m.sender.username if m.sender else str(m.sender_id)
        lines.append(f'[{ts}] {uname}: {m.text}')
    content = '\n'.join(lines) + ('\n' if lines else '')
    buf = BytesIO(content.encode('utf-8'))
    buf.seek(0)
    return send_file(
        buf,
        mimetype='text/plain; charset=utf-8',
        as_attachment=True,
        download_name=f'channel_{channel_id}.txt',
    )
