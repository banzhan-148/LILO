from flask import Blueprint, render_template, abort
from .models import User, Channel, ChannelMember

bp = Blueprint('main', __name__)


@bp.get('/')
def index():
    return render_template('index.html')


@bp.get('/u/<username>')
def profile(username):
    user = User.query.filter_by(username=username).first()
    if not user:
        abort(404)
    # public channels the user is a member of
    memberships = ChannelMember.query.filter_by(user_id=user.id).all()
    channels = []
    for m in memberships:
        ch = Channel.query.get(m.channel_id)
        if ch:
            channels.append(ch)
    channels.sort(key=lambda c: c.name)
    return render_template('profile.html', profile_user=user, channels=channels)
