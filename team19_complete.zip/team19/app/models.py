from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from .extensions import db


class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255))
    bio = db.Column(db.Text, default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    failed_logins = db.Column(db.Integer, default=0)
    locked_until = db.Column(db.DateTime, nullable=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)


class Channel(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), unique=True, nullable=False, index=True)
    creator_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    creator = db.relationship('User', backref='created_channels')
    members = db.relationship('ChannelMember', back_populates='channel', cascade='all, delete-orphan')
    messages = db.relationship('Message', back_populates='channel', cascade='all, delete-orphan')


class ChannelMember(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    channel_id = db.Column(db.Integer, db.ForeignKey('channel.id'), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    joined_at = db.Column(db.DateTime, default=datetime.utcnow)

    channel = db.relationship('Channel', back_populates='members')
    user = db.relationship('User', backref='channel_memberships')

    __table_args__ = (
        db.UniqueConstraint('channel_id', 'user_id', name='uq_channel_member'),
    )


class Chat(db.Model):
    """Private 1-on-1 chat. user1_id < user2_id always to avoid duplicates."""
    id = db.Column(db.Integer, primary_key=True)
    user1_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    user2_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    user1 = db.relationship('User', foreign_keys=[user1_id], backref='chats_as_user1')
    user2 = db.relationship('User', foreign_keys=[user2_id], backref='chats_as_user2')
    messages = db.relationship('Message', back_populates='chat', cascade='all, delete-orphan')

    __table_args__ = (
        db.UniqueConstraint('user1_id', 'user2_id', name='uq_chat_pair'),
    )


class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    text = db.Column(db.Text, nullable=False)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False, index=True)
    chat_id = db.Column(db.Integer, db.ForeignKey('chat.id'), nullable=True, index=True)
    channel_id = db.Column(db.Integer, db.ForeignKey('channel.id'), nullable=True, index=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow, index=True)

    sender = db.relationship('User', backref='messages')
    chat = db.relationship('Chat', back_populates='messages')
    channel = db.relationship('Channel', back_populates='messages')
