"""
Клиент шины Ткань → файлы JSON (без HTTP).
"""
from __future__ import annotations

from typing import Any

import file_bus


class BusError(Exception):
    def __init__(self, message: str, status: int | None = None, payload: dict | None = None):
        super().__init__(message)
        self.status = status
        self.payload = payload or {}


def send_repair_request(
    *,
    external_ref: str,
    customer_name: str,
    customer_phone: str = "",
    customer_email: str = "",
    item_name: str,
    item_size: str = "",
    item_qty: int = 1,
    defect: str,
    note: str = "",
) -> dict[str, Any]:
    """Записать заявку в общую папку to_atelier/."""
    try:
        path = file_bus.write_repair_request(
            external_ref=external_ref,
            customer_name=customer_name,
            customer_phone=customer_phone,
            customer_email=customer_email,
            item_name=item_name,
            item_size=item_size,
            item_qty=item_qty,
            defect=defect,
            note=note,
        )
    except Exception as e:
        raise BusError(f"не удалось записать файл шины: {e}") from e

    return {
        "ok": True,
        "duplicate": False,
        "order_id": None,
        "order_number": "(ожидает ателье)",
        "status": "отправлено",
        "path": str(path),
    }


def get_repair_status(external_ref: str) -> dict[str, Any]:
    """Прочитать статус из to_tkan/."""
    data = file_bus.read_repair_status(external_ref)
    if not data:
        raise BusError("status_not_found")
    return {
        "ok": True,
        "status": data.get("status") or "",
        "order_number": data.get("order_number") or "",
        "order_id": data.get("order_id"),
        "total": data.get("total") or 0,
        "message": data.get("message") or "",
    }


def sync_all_statuses_into_db(db_conn) -> int:
    """Обновить repair_tickets по всем файлам в to_tkan/."""
    n = 0
    for data in file_bus.list_repair_statuses():
        ref = data.get("external_ref") or ""
        if not ref:
            continue
        row = db_conn.execute(
            "select id from repair_tickets where external_ref=?", (ref,)
        ).fetchone()
        if not row:
            continue
        db_conn.execute(
            """update repair_tickets
               set atelier_status=?,
                   atelier_number=COALESCE(NULLIF(?, ''), atelier_number),
                   atelier_order_id=COALESCE(?, atelier_order_id),
                   updated=current_timestamp
               where external_ref=?""",
            (
                data.get("status") or "",
                data.get("order_number") or "",
                data.get("order_id"),
                ref,
            ),
        )
        n += 1
    if n:
        db_conn.commit()
    return n
