"""UI и API для внешних модулей Ателье."""
from __future__ import annotations

import logging

from flask import (Blueprint, render_template, request, redirect,
                   url_for, flash, abort)

from config import Config
from db import q
from utils import login_required, role_required, clean_text, safe_int, current_user, log_action
from modules.notify import NotifyModule
from modules.export_1c import Export1CModule
from modules.qr_label import QRLabelModule

logger = logging.getLogger(__name__)
bp = Blueprint('ext_modules', __name__, url_prefix='/modules')


def _base_dir():
    import config as cfg_mod
    return getattr(cfg_mod, 'BASE_DIR', None)


def _notify() -> NotifyModule:
    return NotifyModule(_base_dir())


def _export() -> Export1CModule:
    return Export1CModule(_base_dir())


def _qr() -> QRLabelModule:
    return QRLabelModule()


@bp.route('/')
@login_required
@role_required('admin', 'receptionist', 'director')
def index():
    """Список внешних модулей."""
    modules = [
        {
            'code': NotifyModule.code,
            'name': NotifyModule.name,
            'description': NotifyModule.description,
            'url': url_for('ext_modules.notify_page'),
        },
        {
            'code': Export1CModule.code,
            'name': Export1CModule.name,
            'description': Export1CModule.description,
            'url': url_for('ext_modules.export_page'),
        },
        {
            'code': QRLabelModule.code,
            'name': QRLabelModule.name,
            'description': QRLabelModule.description,
            'url': url_for('ext_modules.qr_page'),
        },
    ]
    return render_template('modules/index.html', modules=modules)


# ---------- 1. Уведомления ----------
@bp.route('/notify', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'receptionist', 'director')
def notify_page():
    mod = _notify()
    if request.method == 'POST':
        order_id = safe_int(request.form.get('order_id'), 0)
        phone = clean_text(request.form.get('phone', ''), 32)
        custom = clean_text(request.form.get('text', ''), 500)

        order = None
        if order_id:
            order = q(
                """SELECT o.*, c.full_name AS client_name, c.phone AS client_phone
                   FROM orders o LEFT JOIN clients c ON c.id = o.client_id
                   WHERE o.id=? AND o.is_deleted=0""",
                (order_id,), one=True,
            )
            if not order:
                flash('Заказ не найден', 'error')
                return redirect(url_for('ext_modules.notify_page'))
            if not phone:
                phone = order.get('client_phone') or ''

        if order and not custom:
            result = mod.notify_order_status(
                phone=phone,
                client_name=order.get('client_name') or '',
                order_number=order.get('number') or '',
                status=order.get('status') or '',
            )
        else:
            result = mod.send(
                phone=phone,
                text=custom or 'Сообщение из АИС «Ателье»',
                order_number=(order or {}).get('number', ''),
            )

        if result.get('ok'):
            flash(result.get('message') or 'Отправлено', 'ok')
            log_action('Внешний модуль: уведомление', 'order', order_id or 0)
        else:
            flash(f"Ошибка: {result.get('error')}", 'error')
        return redirect(url_for('ext_modules.notify_page'))

    orders = q(
        """SELECT o.id, o.number, o.status, c.full_name AS client_name, c.phone AS client_phone
           FROM orders o LEFT JOIN clients c ON c.id = o.client_id
           WHERE o.is_deleted=0 ORDER BY o.id DESC LIMIT 50"""
    )
    return render_template(
        'modules/notify.html',
        orders=orders,
        history=mod.recent(25),
        module_name=NotifyModule.name,
    )


# ---------- 2. Экспорт 1С ----------
@bp.route('/export', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'director')
def export_page():
    mod = _export()
    if request.method == 'POST':
        order_id = safe_int(request.form.get('order_id'), 0)
        order = q(
            """SELECT o.*, c.full_name AS client_name
               FROM orders o LEFT JOIN clients c ON c.id = o.client_id
               WHERE o.id=? AND o.is_deleted=0""",
            (order_id,), one=True,
        )
        if not order:
            flash('Заказ не найден', 'error')
            return redirect(url_for('ext_modules.export_page'))
        items = q('SELECT name, qty, price FROM order_items WHERE order_id=?', (order_id,))
        result = mod.export_order(order, items)
        if result.get('ok'):
            flash(result['message'], 'ok')
            log_action('Внешний модуль: экспорт 1С', 'order', order_id)
        else:
            flash(f"Ошибка: {result.get('error')}", 'error')
        return redirect(url_for('ext_modules.export_page'))

    orders = q(
        """SELECT o.id, o.number, o.status, o.total, c.full_name AS client_name
           FROM orders o LEFT JOIN clients c ON c.id = o.client_id
           WHERE o.is_deleted=0 ORDER BY o.id DESC LIMIT 50"""
    )
    return render_template(
        'modules/export.html',
        orders=orders,
        exports=mod.list_exports(20),
        module_name=Export1CModule.name,
    )


# ---------- 3. QR-этикетки ----------
@bp.route('/qr', methods=['GET', 'POST'])
@login_required
@role_required('admin', 'receptionist', 'worker', 'director')
def qr_page():
    mod = _qr()
    label = None
    if request.method == 'POST':
        order_id = safe_int(request.form.get('order_id'), 0)
        order = q(
            """SELECT o.*, c.full_name AS client_name
               FROM orders o LEFT JOIN clients c ON c.id = o.client_id
               WHERE o.id=? AND o.is_deleted=0""",
            (order_id,), one=True,
        )
        if not order:
            flash('Заказ не найден', 'error')
            return redirect(url_for('ext_modules.qr_page'))
        items = q('SELECT name, qty, price FROM order_items WHERE order_id=?', (order_id,))
        label = mod.label_data(order, items)
        log_action('Внешний модуль: QR-этикетка', 'order', order_id)

    orders = q(
        """SELECT o.id, o.number, o.status, c.full_name AS client_name
           FROM orders o LEFT JOIN clients c ON c.id = o.client_id
           WHERE o.is_deleted=0 ORDER BY o.id DESC LIMIT 50"""
    )
    return render_template(
        'modules/qr.html',
        orders=orders,
        label=label,
        module_name=QRLabelModule.name,
    )
