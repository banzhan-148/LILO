"""
Внешний модуль: этикетки / QR-коды для заказов.

Генерирует HTML-этикетку и URL QR (внешний QR API без установки библиотек).
"""
from __future__ import annotations

from typing import Any
from urllib.parse import quote


class QRLabelModule:
    """Печать этикетки и QR заказа."""

    name = 'QR-этикетки заказов'
    code = 'qr_label'
    description = (
        'Формирует этикетку заказа с QR-кодом для склада и выдачи. '
        'QR строится через внешний API (не нужна установка qrcode).'
    )

    # Публичный QR-генератор (внешний сервис)
    QR_API = 'https://api.qrserver.com/v1/create-qr-code/'

    def build_payload(self, order: dict[str, Any]) -> str:
        number = order.get('number') or str(order.get('id') or '')
        status = order.get('status') or ''
        client = order.get('client_name') or ''
        return f"ATELIER|{number}|{status}|{client}"

    def qr_image_url(self, order: dict[str, Any], size: int = 180) -> str:
        data = self.build_payload(order)
        return f"{self.QR_API}?size={size}x{size}&data={quote(data)}"

    def label_data(self, order: dict[str, Any], items: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        if not order:
            return {'ok': False, 'error': 'order_required'}
        return {
            'ok': True,
            'order_number': order.get('number') or '',
            'status': order.get('status') or '',
            'client_name': order.get('client_name') or '',
            'work_type': order.get('work_type') or '',
            'total': order.get('total') or 0,
            'items': items or [],
            'qr_url': self.qr_image_url(order),
            'payload': self.build_payload(order),
        }
