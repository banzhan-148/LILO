"""
Внешний модуль: выгрузка заказов во внешнюю учётную систему (формат «1С-обмен»).

Пишет JSON-пакеты в data/export_1c/ — их может забрать внешняя программа учёта.
"""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class Export1CModule:
    """Экспорт заказов во внешнюю систему."""

    name = 'Экспорт в учёт (1С)'
    code = 'export_1c'
    description = (
        'Формирует JSON-пакеты заказов для внешней бухгалтерии / 1С. '
        'Файлы сохраняются в data/export_1c/.'
    )

    def __init__(self, base_dir: str | None = None):
        root = Path(base_dir) if base_dir else Path(__file__).resolve().parent.parent
        self.out_dir = root / 'data' / 'export_1c'
        self.out_dir.mkdir(parents=True, exist_ok=True)

    def export_order(self, order: dict[str, Any], items: list[dict[str, Any]] | None = None) -> dict[str, Any]:
        """Выгрузить один заказ."""
        if not order or not order.get('id'):
            return {'ok': False, 'error': 'order_required'}

        payload = {
            'format': 'atelier-1c-v1',
            'exported_at': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
            'document': {
                'type': 'order',
                'id': order.get('id'),
                'number': order.get('number'),
                'status': order.get('status'),
                'work_type': order.get('work_type'),
                'total': order.get('total') or 0,
                'paid': order.get('paid') or 0,
                'client_id': order.get('client_id'),
                'client_name': order.get('client_name') or order.get('full_name') or '',
                'description': order.get('description') or '',
                'created_at': order.get('created_at') or '',
                'due_date': order.get('due_date') or '',
            },
            'items': [
                {
                    'name': it.get('name'),
                    'qty': it.get('qty'),
                    'price': it.get('price'),
                }
                for it in (items or [])
            ],
        }

        fname = f"order_{order.get('number') or order['id']}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        # безопасное имя файла
        safe = ''.join(c if c.isalnum() or c in '-_.' else '_' for c in fname)
        path = self.out_dir / safe
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')

        return {
            'ok': True,
            'path': str(path),
            'filename': safe,
            'message': f'Пакет для 1С сохранён: {safe}',
        }

    def list_exports(self, limit: int = 20) -> list[dict[str, Any]]:
        files = sorted(self.out_dir.glob('*.json'), key=lambda p: p.stat().st_mtime, reverse=True)
        out = []
        for p in files[:limit]:
            out.append({
                'filename': p.name,
                'size': p.stat().st_size,
                'mtime': datetime.fromtimestamp(p.stat().st_mtime).strftime('%Y-%m-%d %H:%M'),
            })
        return out
