"""
Внешний модуль: уведомления клиентам (SMS / мессенджер — имитация шлюза).

В учебной среде сообщения пишутся в JSON-журнал notifications.jsonl
в папке data/notifications/. В проде сюда подключают SMS API / Telegram.
"""
from __future__ import annotations

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


class NotifyModule:
    """Внешний шлюз уведомлений."""

    name = 'Уведомления клиентам'
    code = 'notify'
    description = (
        'Отправка SMS/сообщений клиенту при смене статуса заказа. '
        'В учебной версии — запись в журнал (имитация внешнего SMS-шлюза).'
    )

    def __init__(self, base_dir: str | None = None):
        root = Path(base_dir) if base_dir else Path(__file__).resolve().parent.parent
        self.log_dir = root / 'data' / 'notifications'
        self.log_dir.mkdir(parents=True, exist_ok=True)
        self.log_file = self.log_dir / 'notifications.jsonl'

    def send(
        self,
        *,
        phone: str,
        text: str,
        order_number: str = '',
        channel: str = 'sms',
    ) -> dict[str, Any]:
        phone = (phone or '').strip()
        text = (text or '').strip()
        if not phone:
            return {'ok': False, 'error': 'phone_required'}
        if not text:
            return {'ok': False, 'error': 'text_required'}

        entry = {
            'ts': datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ'),
            'channel': channel,
            'phone': phone,
            'text': text,
            'order_number': order_number or '',
            'provider': 'mock-sms-gateway',
            'status': 'accepted',
        }
        with open(self.log_file, 'a', encoding='utf-8') as f:
            f.write(json.dumps(entry, ensure_ascii=False) + '\n')

        return {
            'ok': True,
            'message': f'Уведомление принято шлюзом ({channel}) → {phone}',
            'entry': entry,
        }

    def notify_order_status(
        self,
        *,
        phone: str,
        client_name: str,
        order_number: str,
        status: str,
    ) -> dict[str, Any]:
        text = (
            f'Ателье: заказ {order_number}, статус «{status}». '
            f'{client_name}, ваш заказ обновлён.'
        )
        return self.send(phone=phone, text=text, order_number=order_number)

    def recent(self, limit: int = 30) -> list[dict[str, Any]]:
        if not self.log_file.is_file():
            return []
        lines = self.log_file.read_text(encoding='utf-8').strip().splitlines()
        out: list[dict[str, Any]] = []
        for line in lines[-limit:]:
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        out.reverse()
        return out
