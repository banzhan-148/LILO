"""
Внешние модули АИС «Ателье».

Подключаются как отдельные пакеты (не смешиваются с core services).
"""
from modules.notify import NotifyModule
from modules.export_1c import Export1CModule
from modules.qr_label import QRLabelModule

__all__ = ['NotifyModule', 'Export1CModule', 'QRLabelModule']
