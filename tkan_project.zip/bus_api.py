"""
API шины: приём данных от Ателье (Ателье → Ткань).

POST /api/bus/v1/repair-status  — обновление статуса ремонта
POST /api/bus/v1/repair-done    — ремонт готов: статус + стоимость
"""
from __future__ import annotations

from functools import wraps

from flask import Blueprint, jsonify, request

from config import BUS_API_KEY
from db import db

bus_api_bp = Blueprint("bus_api", __name__, url_prefix="/api/bus/v1")


def _require_bus_key(f):
    @wraps(f)
    def wrapper(*args, **kwargs):
        got = request.headers.get("X-Bus-Key", "")
        if not BUS_API_KEY or got != BUS_API_KEY:
            return jsonify({"ok": False, "error": "unauthorized"}), 401
        return f(*args, **kwargs)
    return wrapper


def _clean(s, max_len=500):
    if not s:
        return ""
    return " ".join(str(s).split())[:max_len]


@bus_api_bp.post("/repair-status")
@_require_bus_key
def repair_status():
    """
    Ателье сообщает новый статус заявки.

    {
      "external_ref": "tkan-order-12-...",
      "status": "в работе",
      "order_number": "AT-2026-00005",
      "order_id": 5
    }
    """
    data = request.get_json(silent=True) or {}
    external_ref = _clean(data.get("external_ref"), 64)
    status = _clean(data.get("status"), 64)
    order_number = _clean(data.get("order_number"), 64)
    order_id = data.get("order_id")

    if not external_ref:
        return jsonify({"ok": False, "error": "external_ref_required"}), 400
    if not status:
        return jsonify({"ok": False, "error": "status_required"}), 400

    con = db()
    row = con.execute(
        "select id from repair_tickets where external_ref=?",
        (external_ref,),
    ).fetchone()
    if not row:
        return jsonify({"ok": False, "error": "ticket_not_found"}), 404

    con.execute(
        """update repair_tickets
           set atelier_status=?,
               atelier_number=COALESCE(NULLIF(?, ''), atelier_number),
               atelier_order_id=COALESCE(?, atelier_order_id),
               updated=current_timestamp
           where external_ref=?""",
        (status, order_number, order_id, external_ref),
    )
    con.commit()
    return jsonify({"ok": True, "external_ref": external_ref, "status": status})


@bus_api_bp.post("/repair-done")
@_require_bus_key
def repair_done():
    """
    Ателье: ремонт завершён / выдан.
    Можно передать стоимость ремонта.

    {
      "external_ref": "tkan-order-12-...",
      "status": "готов",
      "order_number": "AT-2026-00005",
      "order_id": 5,
      "total": 1500.0,
      "message": "Молния заменена"
    }
    """
    data = request.get_json(silent=True) or {}
    external_ref = _clean(data.get("external_ref"), 64)
    status = _clean(data.get("status") or "готов", 64)
    order_number = _clean(data.get("order_number"), 64)
    order_id = data.get("order_id")
    message = _clean(data.get("message"), 500)
    try:
        total = float(data.get("total") or 0)
    except (TypeError, ValueError):
        total = 0.0

    if not external_ref:
        return jsonify({"ok": False, "error": "external_ref_required"}), 400

    con = db()
    row = con.execute(
        "select id, defect from repair_tickets where external_ref=?",
        (external_ref,),
    ).fetchone()
    if not row:
        return jsonify({"ok": False, "error": "ticket_not_found"}), 404

    # Дописываем итог в defect/note-поле через отдельный апдейт статуса
    note_extra = ""
    if message:
        note_extra = f" | Ателье: {message}"
    if total > 0:
        note_extra += f" | Стоимость: {total:.0f} ₽"

    con.execute(
        """update repair_tickets
           set atelier_status=?,
               atelier_number=COALESCE(NULLIF(?, ''), atelier_number),
               atelier_order_id=COALESCE(?, atelier_order_id),
               defect=defect || ?,
               updated=current_timestamp
           where external_ref=?""",
        (status, order_number, order_id, note_extra, external_ref),
    )
    con.commit()
    return jsonify({
        "ok": True,
        "external_ref": external_ref,
        "status": status,
        "total": total,
    })
