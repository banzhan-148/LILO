"""
Клиент шины: Ткань → Ателье.

Отправляет заявку на ремонт бракованного товара и умеет
запрашивать статус созданного в ателье заказа.
"""
from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any

from config import BUS_API_KEY, BUS_ATELIER_URL


class BusError(Exception):
    def __init__(self, message: str, status: int | None = None, payload: dict | None = None):
        super().__init__(message)
        self.status = status
        self.payload = payload or {}


def _request(method: str, path: str, body: dict | None = None, timeout: float = 8.0) -> dict[str, Any]:
    url = BUS_ATELIER_URL.rstrip('/') + path
    data = None
    headers = {
        'X-Bus-Key': BUS_API_KEY,
        'Accept': 'application/json',
        'User-Agent': 'TkanBusClient/1.0',
    }
    if body is not None:
        data = json.dumps(body, ensure_ascii=False).encode('utf-8')
        headers['Content-Type'] = 'application/json; charset=utf-8'

    req = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode('utf-8')
            return json.loads(raw) if raw else {}
    except urllib.error.HTTPError as e:
        try:
            payload = json.loads(e.read().decode('utf-8'))
        except Exception:
            payload = {}
        raise BusError(
            payload.get('error') or f'HTTP {e.code}',
            status=e.code,
            payload=payload,
        ) from e
    except urllib.error.URLError as e:
        raise BusError(f'connection_failed: {e.reason}') from e
    except TimeoutError as e:
        raise BusError('timeout') from e


def send_repair_request(
    *,
    external_ref: str,
    customer_name: str,
    customer_phone: str = '',
    customer_email: str = '',
    item_name: str,
    item_size: str = '',
    item_qty: int = 1,
    defect: str,
    note: str = '',
) -> dict[str, Any]:
    """
    Создать заявку на ремонт в Ателье.
    Возвращает dict с order_id, order_number, status, duplicate.
    """
    body = {
        'external_ref': external_ref,
        'source': 'tkan',
        'customer': {
            'name': customer_name,
            'phone': customer_phone or '',
            'email': customer_email or '',
        },
        'item': {
            'name': item_name,
            'size': item_size or '',
            'qty': item_qty,
        },
        'defect': defect,
        'note': note,
    }
    return _request('POST', '/api/bus/v1/repair', body=body)


def get_repair_status(external_ref: str) -> dict[str, Any]:
    """Получить статус заявки по external_ref."""
    from urllib.parse import quote
    return _request('GET', f'/api/bus/v1/repair/{quote(external_ref, safe="")}')
