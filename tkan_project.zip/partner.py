"""
Партнёрская шина «Ткань» ↔ «Ателье».

Обеспечивает:
- страницу партнёра (/partner)
- редирект «Перейти к партнёру» (/go-partner) с UTM/ref
- передачу контекста (откуда пришли) через query-параметры
"""
from __future__ import annotations

from urllib.parse import urlencode, urlparse, urlunparse, parse_qs

from flask import Blueprint, render_template, redirect, request, current_app, session

partner_bp = Blueprint("partner", __name__)


def _partner_cfg() -> dict:
    return {
        "name": current_app.config.get("PARTNER_NAME", "АИС «Ателье»"),
        "url": current_app.config.get("PARTNER_URL", "http://127.0.0.1:5000"),
        "short": current_app.config.get("PARTNER_SHORT", "Ателье"),
        "desc": current_app.config.get(
            "PARTNER_DESC",
            "Партнёрский сервис пошива и ремонта одежды. Индивидуальные заказы, подгонка, ремонт.",
        ),
        "cta": current_app.config.get("PARTNER_CTA", "Нужен пошив или ремонт?"),
    }


@partner_bp.route("/partner")
def partner_page():
    """Информационная страница о партнёре + кнопка перехода."""
    cfg = _partner_cfg()
    return render_template("partner.html", partner=cfg)


@partner_bp.route("/go-partner")
def go_partner():
    """
    Редирект на партнёра с метками.
    Пример: /go-partner?from=cart → партнёр получит ?utm_source=tkan&utm_medium=partner&utm_campaign=cart&ref=tkan
    """
    cfg = _partner_cfg()
    target = cfg["url"].rstrip("/")

    # Базовый landing партнёра (можно переопределить)
    path = request.args.get("path", "/")
    if not path.startswith("/"):
        path = "/" + path

    source = request.args.get("from", "site")
    # Сохраняем источник клика в сессии (для аналитики внутри Ткани)
    session["last_partner_click"] = source

    params = {
        "utm_source": "tkan",
        "utm_medium": "partner_bus",
        "utm_campaign": source,
        "ref": "tkan",
    }
    # Пробрасываем дополнительные безопасные параметры
    for key in ("order_id", "product_id", "user_hint"):
        val = request.args.get(key)
        if val and len(val) < 64:
            params[key] = val

    parsed = urlparse(target + path)
    q = parse_qs(parsed.query)
    for k, v in params.items():
        q[k] = [v]
    new_query = urlencode({k: v[0] for k, v in q.items()})
    final = urlunparse(parsed._replace(query=new_query))
    return redirect(final, code=302)
